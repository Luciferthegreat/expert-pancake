﻿using LowesKiosk.DataAccess.Helpers;
using LowesKiosk.DataModel;
using System;
using System.Collections.ObjectModel;
using System.Data.SQLite;

namespace LowesKiosk.DataAccess.Repositories
{
    public class OrderMasterRepository
    {
        #region Variables
        private readonly DbHelper dbHelper = new DbHelper();
        private readonly ErrorLogHelper errorLogHelper = new ErrorLogHelper();
        #endregion

        #region Methods

        public ObservableCollection<OrderMaster> GetAllOrderMaster()
        {
            ObservableCollection<OrderMaster> collectionOfOrderMaster = new ObservableCollection<OrderMaster>();
            try
            {
                using (var sqLiteConnection = new SQLiteConnection(dbHelper.DbConnection))
                {
                    var query = "SELECT Id, ProductType, ProductName, Sheen, BucketSize, Quantity " +
                        "FROM OrderMaster";

                    using (var sqLiteCommand = new SQLiteCommand(query, sqLiteConnection))
                    {
                        using (var sqLiteDataReader = sqLiteCommand.ExecuteReader())
                        {
                            while (sqLiteDataReader.Read())
                            {
                                var orderMaster = new OrderMaster
                                {
                                    Id = int.Parse(sqLiteDataReader["Id"].ToString()),
                                    ProductType = sqLiteDataReader["ProductType"].ToString(),
                                    ProductName = sqLiteDataReader["ProductName"].ToString(),
                                    Sheen = sqLiteDataReader["Sheen"].ToString(),
                                    BucketSize = sqLiteDataReader["BucketSize"].ToString(),
                                    Quantity = int.Parse(sqLiteDataReader["Quantity"].ToString())
                                };

                                collectionOfOrderMaster.Add(orderMaster);
                            }
                        }
                    }
                    sqLiteConnection.Close();
                }
            }
            catch (Exception ex)
            {
                errorLogHelper.LogErrorAsync("OrderMasterRepository", "GetAllOrderMaster", ex);
            }

            return collectionOfOrderMaster;
        }

        public void DeleteOrderMaster(OrderMaster pOrderMaster)
        {
            try
            {
                using (var sqLiteConnection = new SQLiteConnection(dbHelper.DbConnection))
                {
                    using (var sqLiteCommand = new SQLiteCommand(sqLiteConnection))
                    {
                        sqLiteCommand.CommandText = "DELETE FROM OrderMaster WHERE Id = @Id";
                        sqLiteCommand.Prepare();
                        sqLiteCommand.Parameters.AddWithValue("@Id", pOrderMaster.Id);

                        sqLiteCommand.ExecuteNonQuery();
                    }
                    sqLiteConnection.Close();
                }
            }
            catch (Exception ex)
            {
                errorLogHelper.LogErrorAsync("OrderMasterRepository", "DeleteOrderMaster", ex);
            }
        }

        public int InsertOrderMaster(OrderMaster pOrderMaster)
        {
            var result = -1;

            try
            {
                using (var sqLiteConnection = new SQLiteConnection(dbHelper.DbConnection))
                {
                    using (var sqLiteCommand = new SQLiteCommand(sqLiteConnection))
                    {
                        sqLiteCommand.CommandText = "INSERT INTO OrderMaster(ProductType, ProductName, Sheen, BucketSize, Quantity, OrderDate) "
                            + "VALUES(@ProductType, @ProductName, @Sheen, @BucketSize, @Quantity, @OrderDate)";
                        sqLiteCommand.Prepare();
                        sqLiteCommand.Parameters.AddWithValue("@ProductType", pOrderMaster.ProductType);
                        sqLiteCommand.Parameters.AddWithValue("@ProductName", pOrderMaster.ProductName);
                        sqLiteCommand.Parameters.AddWithValue("@Sheen", pOrderMaster.Sheen);
                        sqLiteCommand.Parameters.AddWithValue("@BucketSize", pOrderMaster.BucketSize);
                        sqLiteCommand.Parameters.AddWithValue("@Quantity", pOrderMaster.Quantity);
                        sqLiteCommand.Parameters.AddWithValue("@OrderDate", pOrderMaster.OrderDate);

                        result = sqLiteCommand.ExecuteNonQuery();

                        var insertedSystemId = 0;
                        using (var sqLiteCommandrowid = new SQLiteCommand("SELECT last_insert_rowid();", sqLiteConnection))
                        {
                            using (var sqLiteDataReader = sqLiteCommandrowid.ExecuteReader())
                            {
                                while (sqLiteDataReader.Read())
                                {
                                    insertedSystemId = int.Parse(sqLiteDataReader["last_insert_rowid()"].ToString());
                                }
                            }
                        }
                    }
                    sqLiteConnection.Close();
                }
            }
            catch (Exception ex)
            {
                errorLogHelper.LogErrorAsync("OrderMasterRepository", "InsertOrderMaster", ex);
            }

            return result;
        }

        public void UpdateOrderMaster(OrderMaster pOrderMaster)
        {
            try
            {
                using (var sqLiteConnection = new SQLiteConnection(dbHelper.DbConnection))
                {
                    using (var sqLiteCommand = new SQLiteCommand(sqLiteConnection))
                    {
                        sqLiteCommand.CommandText = "UPDATE OrderMaster "
                            + "SET ProductType = @ProductType, "
                            + "ProductName = @ProductName, "
                            + "Sheen = @Sheen, "
                            + "BucketSize = @BucketSize, "
                            + "Quantity = @Quantity, "
                            + "OrderDate = @OrderDate "
                            + "WHERE Id = @Id";
                        sqLiteCommand.Prepare();
                        sqLiteCommand.Parameters.AddWithValue("@ProductType", pOrderMaster.ProductType);
                        sqLiteCommand.Parameters.AddWithValue("@ProductName", pOrderMaster.ProductName);
                        sqLiteCommand.Parameters.AddWithValue("@Sheen", pOrderMaster.Sheen);
                        sqLiteCommand.Parameters.AddWithValue("@BucketSize", pOrderMaster.BucketSize);
                        sqLiteCommand.Parameters.AddWithValue("@Quantity", pOrderMaster.Quantity);
                        sqLiteCommand.Parameters.AddWithValue("@OrderDate", pOrderMaster.OrderDate);
                        sqLiteCommand.Parameters.AddWithValue("@Id", pOrderMaster.Id);

                        sqLiteCommand.ExecuteNonQuery();
                    }

                    sqLiteConnection.Close();
                }
            }
            catch (Exception ex)
            {
                errorLogHelper.LogErrorAsync("OrderMasterRepository", "UpdateOrderMaster", ex);
            }
        }

        public void InsertOrUpdateSystem(OrderMaster pOrderMaster)
        {
            if (pOrderMaster.Id != null)
            {
                UpdateOrderMaster(pOrderMaster);
            }
            else
            {
                InsertOrderMaster(pOrderMaster);
            }
        }
        #endregion
    }
}
