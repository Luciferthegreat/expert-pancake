﻿using System;
using System.IO;
using System.Reflection;

namespace LowesKiosk.DataAccess.Helpers
{
    public class ErrorLogHelper
    {
        public void LogErrorAsync(string className, string methodName, Exception ex)
        {
            try
            {
                var folderPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "/Logs/";
                var filePath = folderPath + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";

                if (!Directory.Exists(folderPath)) { Directory.CreateDirectory(folderPath); }

                using (var sw = new StreamWriter(filePath, true))
                {
                    sw.WriteLineAsync(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
                    sw.WriteLineAsync($"{className}, {methodName}");
                    sw.WriteLineAsync(ex.Message);
                    sw.WriteLineAsync(ex.InnerException?.ToString() ?? string.Empty);
                    sw.WriteLineAsync(ex.StackTrace + Environment.NewLine + Environment.NewLine);
                }
            }
            catch
            {
                // ignored
            }
        }

        public void LogErrorAsync(string className, string methodName, string message)
        {
            try
            {
                var folderPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "/Logs/";
                var filePath = folderPath + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";

                if (!Directory.Exists(folderPath)) { Directory.CreateDirectory(folderPath); }

                using (var sw = new StreamWriter(filePath, true))
                {
                    sw.WriteLineAsync(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
                    sw.WriteLineAsync($"{className}, {methodName}");
                    sw.WriteLineAsync(message + Environment.NewLine);
                }
            }
            catch
            {
                // ignored
            }
        }
    }
}
