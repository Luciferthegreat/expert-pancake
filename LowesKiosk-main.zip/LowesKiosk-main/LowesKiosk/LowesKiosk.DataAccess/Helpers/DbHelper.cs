﻿using Dapper;
using System;
using System.Data;
using System.Data.SQLite;
using System.IO;

namespace LowesKiosk.DataAccess.Helpers
{
    public class DbHelper
    {
        private SQLiteConnection _dbConnection;
        private const string DbFilePath = "./LowesKiosk.sqlite";

        public SQLiteConnection DbConnection
        {
            get
            {
                if (_dbConnection != null && _dbConnection.State == ConnectionState.Open)
                {
                    return _dbConnection;
                }
                else
                {
                    _dbConnection = new SQLiteConnection($"Data Source={DbFilePath};Version=3;");
                    _dbConnection.Open();

                    return _dbConnection;
                }
            }
            set { _dbConnection = value; }
        }

        public void CreateDb()
        {
            if (!File.Exists(DbFilePath))
            {
                SQLiteConnection.CreateFile(DbFilePath);

                var dbConnection = DbConnection;

                SeedDatabase();
            }
        }

        public void ExecuteNonQuery(string commandText)
        {
            // Ensure we have a connection
            if (DbConnection == null)
            {
                throw new NullReferenceException("Please provide a connection");
            }

            // Ensure that the connection state is Open
            if (DbConnection.State != ConnectionState.Open)
            {
                DbConnection.Open();
            }

            // Use Dapper to execute the given query
            DbConnection.Execute(commandText);
        }

        // ReSharper disable once MethodOverloadWithOptionalParameter
        public void ExecuteNonQuery(string commandText, object param = null)
        {
            // Ensure we have a connection
            if (DbConnection == null)
            {
                throw new NullReferenceException("Please provide a connection");
            }

            // Ensure that the connection state is Open
            if (DbConnection.State != ConnectionState.Open)
            {
                DbConnection.Open();
            }

            // Use Dapper to execute the given query
            DbConnection.Execute(commandText, param);
        }

        public void SeedDatabase()
        {
            try
            {
                _dbConnection.Execute(@"
                    CREATE TABLE IF NOT EXISTS [OrderMaster] (
                        [Id] INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                        [ProductType] NVARCHAR(100),
                        [ProductName] NVARCHAR(100),
                        [Sheen] NVARCHAR(100),
                        [BucketSize] NVARCHAR(100),
                        [Quantity] INTEGER,
                        [OrderDate] DATETIME
                    )");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
