﻿using System;
using System.ComponentModel;
using System.Windows.Input;

namespace LowesKiosk.ViewModels
{
    public class ViewModelBase : INotifyPropertyChanged
    {
        public delegate void GeneralHandler(Object sender, EventArgs args);

        public event PropertyChangedEventHandler PropertyChanged;

        public delegate void RequestCloseDelegate();
        public event RequestCloseDelegate RequestCloseEvent;

        //private IViewDispatcher _dispatcher;
        //public IViewDispatcher Dispatcher
        //{
        //    get { return _dispatcher; }
        //    set
        //    {
        //        _dispatcher = value;
        //        Loaded();
        //    }
        //}

        protected virtual void Loaded()
        {
        }

        protected void RequestClose()
        {
            if (RequestCloseEvent != null) RequestCloseEvent();
        }

        protected void NotifyPropertyChanged(string PropertyName)
        {
            if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(PropertyName));
        }

        private bool _busy = false;

        /// <summary>
        /// Busy Flag.  Used to tell when the view model is in an operation.  May be bound using a visibility/enabled converter.
        /// </summary>
        public virtual bool Busy
        {
            get { return _busy; }
            set
            {
                _busy = value;
                NotifyPropertyChanged("Busy");
            }
        }

        public class DelegateCommand : ICommand
        {
            public delegate void ExecuteDelegate(object o);
            public event ExecuteDelegate ExecuteCommand;
            public event EventHandler CanExecuteChanged;

            private bool _canExecute = true;

            public bool CanExecuteParameter
            {
                get { return _canExecute; }
                set { _canExecute = value; RaiseCanExecuteChanged(); }
            }

            public bool CanExecute(object parameter)
            {
                return _canExecute;
            }

            public void Execute(object parameter)
            {
                if (ExecuteCommand != null)
                    ExecuteCommand(parameter);
            }

            public void RaiseCanExecuteChanged()
            {
                if (CanExecuteChanged != null)
                {
                    CanExecuteChanged(this, EventArgs.Empty);
                }
            }
        }
    }
}
