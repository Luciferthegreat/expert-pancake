﻿using LowesKiosk.DataAccess.Repositories;
using LowesKiosk.DataModel;
using LowesKiosk.Extentions;
using LowesKiosk.Helpers;
using LowesKiosk.MvvmFramework;
using LowesKiosk.Views.UserControls;
using System;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Windows;
using System.Windows.Input;

namespace LowesKiosk.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        #region Variables
        OrderMasterRepository orderMasterRepository = new OrderMasterRepository();
        #endregion

        #region Ctor
        public MainViewModel()
        {
            SwitchView("main");
            FillSettingModel();
            FillColorCodeModel();
        }
        #endregion

        #region Properites
        private FrameworkElement _contentControlView;
        public FrameworkElement ContentControlView
        {
            get { return _contentControlView; }
            set
            {
                _contentControlView = value;
                NotifyPropertyChanged("ContentControlView");
            }
        }

        private string _lastView;
        public string LastView
        {
            get { return _lastView; }
            set { _lastView = value; NotifyPropertyChanged("LastView"); }
        }

        private ObservableCollection<OrderMaster> _collectionOfOrderMaster;
        public ObservableCollection<OrderMaster> CollectionOfOrderMaster
        {
            get { return _collectionOfOrderMaster; }
            set { _collectionOfOrderMaster = value; NotifyPropertyChanged("CollectionOfOrderMaster"); }
        }

        private OrderMaster _selectedOrderMaster;
        public OrderMaster SelectedOrderMaster
        {
            get { return _selectedOrderMaster; }
            set { _selectedOrderMaster = value; NotifyPropertyChanged("SelectedOrderMaster"); }
        }

        private string _customerName;
        public string CustomerName
        {
            get { return _customerName; }
            set { _customerName = value; NotifyPropertyChanged("CustomerName"); }
        }

        private SettingModel _currentSettingModel;
        public SettingModel CurrentSettingModel
        {
            get { return _currentSettingModel; }
            set { _currentSettingModel = value; NotifyPropertyChanged("CurrentSettingModel"); }
        }

        private ObservableCollection<ColorCodeModel> _collectionOfColorCode;
        public ObservableCollection<ColorCodeModel> CollectionOfColorCode
        {
            get { return _collectionOfColorCode; }
            set { _collectionOfColorCode = value; NotifyPropertyChanged("CollectionOfColorCode"); }
        }

        private ColorCodeModel _selectedColorCode;
        public ColorCodeModel SelectedColorCode
        {
            get { return _selectedColorCode; }
            set { _selectedColorCode = value; NotifyPropertyChanged("SelectedColorCode"); }
        }

        private ObservableCollection<ColorCodeModel> _collectionOfColorCodeSearch;
        public ObservableCollection<ColorCodeModel> CollectionOfColorCodeSearch
        {
            get { return _collectionOfColorCodeSearch; }
            set { _collectionOfColorCodeSearch = value; NotifyPropertyChanged("CollectionOfColorCodeSearch"); }
        }

        private string _colorCodeSearch;
        public string ColorCodeSearch
        {
            get { return _colorCodeSearch; }
            set
            {
                _colorCodeSearch = value;
                SearchColorCode();
                NotifyPropertyChanged("ColorCodeSearch"); }
        }

        private Visibility _colorCodeSearchVisibility = Visibility.Collapsed;
        public Visibility ColorCodeSearchVisibility
        {
            get { return _colorCodeSearchVisibility; }
            set { _colorCodeSearchVisibility = value; NotifyPropertyChanged("ColorCodeSearchVisibility"); }
        }

        #endregion

        #region Methods
        public void SwitchView(string pViewName)
        {
            switch (pViewName)
            {
                case "main":
                    CollectionOfOrderMaster = new ObservableCollection<OrderMaster>();
                    ContentControlView = new MainUserControl();
                    ContentControlView.DataContext = this;
                    break;
                case "addmore":
                    ContentControlView = new MainUserControl();
                    ContentControlView.DataContext = this;
                    break;
                case "thankyou":
                    InsertOrderMaster();
                    ContentControlView = new ThankYouControl();
                    ContentControlView.DataContext = this;
                    break;
                case "colorsearch":
                    ContentControlView = new CustomColorSearchControl();
                    ContentControlView.DataContext = this;
                    ColorCodeSearch = string.Empty;
                    ColorCodeSearchVisibility = Visibility.Collapsed;
                    break;
                case "colorlist":
                    ContentControlView = new CustomColorListControl();
                    ContentControlView.DataContext = this;
                    break;
                case "mainproduct":
                    SelectedOrderMaster = new OrderMaster();
                    SelectedOrderMaster.Quantity = 1;
                    SelectedOrderMaster.ColorName = SelectedColorCode.ColorName;
                    SelectedOrderMaster.OrderDate = DateTime.Now;
                    ContentControlView = new MainProductUserControl();
                    ContentControlView.DataContext = this;
                    break;
                case "interior":
                    ContentControlView = new InteriorUserControl();
                    ContentControlView.DataContext = this;
                    LastView = "interior";
                    break;

                case "exterior":
                    ContentControlView = new ExteriorUserControl();
                    ContentControlView.DataContext = this;
                    LastView = "exterior";
                    break;

                case "sheen":
                    ContentControlView = new SheenUserControl();
                    ContentControlView.DataContext = this;
                    break;

                case "bucketsize":
                    ContentControlView = new BucketSizeUserControl();
                    ContentControlView.DataContext = this;
                    break;

                case "revieworder":
                    //InsertOrderMaster();
                    //LoadAllOrderMaster();
                    CollectionOfOrderMaster.Add(SelectedOrderMaster);
                    ContentControlView = new ReviewOrderUserControl();
                    ContentControlView.DataContext = this;
                    break;

                default:
                    ContentControlView = new MainUserControl();
                    ContentControlView.DataContext = this;
                    break;
            }
        }

        public void LoadAllOrderMaster()
        {
            CollectionOfOrderMaster = orderMasterRepository.GetAllOrderMaster();
        }

        public void InsertOrderMaster()
        {
            orderMasterRepository.InsertOrUpdateSystem(SelectedOrderMaster);
            CustomerName = string.Empty;
        }

        public void FillSettingModel()
        {
            CurrentSettingModel = new SettingModel();
            CurrentSettingModel.FromEmail = ConfigurationManager.AppSettings["FromEmail"];
            CurrentSettingModel.ServerName = ConfigurationManager.AppSettings["ServerName"];
            CurrentSettingModel.Port = Convert.ToInt32(ConfigurationManager.AppSettings["Port"]);
            CurrentSettingModel.Password = ConfigurationManager.AppSettings["Password"];
        }

        public bool SendEmail(string pSubject, string pBody, string pEmail)
        {
            MailMessage mailMessage = new MailMessage();
            try
            {
                //Mail Address
                mailMessage.From = new MailAddress(CurrentSettingModel.FromEmail);
                //receiver email id
                mailMessage.To.Add(pEmail);
                //subject of the email
                mailMessage.Subject = pSubject;
                //deciding for the attachment

                //add the body of the email
                mailMessage.Body = pBody;
                mailMessage.IsBodyHtml = true;

                //SMTP client
                SmtpClient smtpClient = new SmtpClient(CurrentSettingModel.ServerName);
                //port number for Hot mail
                smtpClient.Port = CurrentSettingModel.Port;
                //credentials to login in to hotmail account
                smtpClient.Credentials = new NetworkCredential(CurrentSettingModel.FromEmail, CurrentSettingModel.Password);
                //enabled SSL
                smtpClient.EnableSsl = true;

                //smtpClient.Timeout = 10000000;
                //Send an email
                smtpClient.Send(mailMessage);

                if (mailMessage.Attachments != null)
                {
                    for (int i = mailMessage.Attachments.Count - 1; i >= 0; i--)
                    {
                        mailMessage.Attachments[i].Dispose();
                    }
                    mailMessage.Attachments.Clear();
                    mailMessage.Attachments.Dispose();
                }
                mailMessage.Dispose();
                mailMessage = null;

                return true;
            }
            catch
            {
                DispatchService.Invoke(() =>
                {
                    MessageBox.Show("Please check your email settings", "Error in Send Email", MessageBoxButton.OK, MessageBoxImage.Information);

                    if (mailMessage.Attachments != null)
                    {
                        for (int i = mailMessage.Attachments.Count - 1; i >= 0; i--)
                        {
                            mailMessage.Attachments[i].Dispose();
                        }
                        mailMessage.Attachments.Clear();
                        mailMessage.Attachments.Dispose();
                    }
                    mailMessage.Dispose();
                    mailMessage = null;
                });

                return false;
            }
        }

        public void FillColorCodeModel()
        {
            CollectionOfColorCode = new ObservableCollection<ColorCodeModel>();
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 1, ColorName = "Lapland Ice", ColorCode = "HGSW1507", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1507.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 2, ColorName = "Wormwood", ColorCode = "HGSW1505", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1505.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 3, ColorName = "Subterranean", ColorCode = "HGSW3221", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW3221.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 4, ColorName = "Cocoon", ColorCode = "HGSW3222", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW3222.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 5, ColorName = "Mortar & Pestle", ColorCode = "HGSW3224", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW3224.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 6, ColorName = "Otter", ColorCode = "HGSW3431", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW3431.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 7, ColorName = "Metric Gray", ColorCode = "HGSW3434", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW3434.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 8, ColorName = "Anthology", ColorCode = "HGSW1431", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1431.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 9, ColorName = "Pretty Purple", ColorCode = "HGSW1432", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1432.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 10, ColorName = "Plumberri", ColorCode = "HGSW1433", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1433.png" });

            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 11, ColorName = "Violet Royale", ColorCode = "HGSW1434", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1434.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 12, ColorName = "Thalia Pink", ColorCode = "HGSW1012", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1012.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 13, ColorName = "Victoria Rose", ColorCode = "HGSW1014", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1014.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 14, ColorName = "Rowan Berries", ColorCode = "HGSW1092", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1092.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 15, ColorName = "Scarlet Maple", ColorCode = "HGSW1091", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1091.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 16, ColorName = "Knock-Out Orange", ColorCode = "HGSW1093", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1093.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 17, ColorName = "Pink Ranunculus", ColorCode = "HGSW1094", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1094.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 18, ColorName = "Aubusson Gold", ColorCode = "HGSW1201", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1201.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 19, ColorName = "Gold Market", ColorCode = "HGSW1202", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1202.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 20, ColorName = "Simply Joyful", ColorCode = "HGSW1204", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1204.png" });

            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 21, ColorName = "Green Verge", ColorCode = "HGSW1241", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1241.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 22, ColorName = "Ecosystem", ColorCode = "HGSW1242", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1242.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 23, ColorName = "Parakeet", ColorCode = "HGSW1243", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1243.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 24, ColorName = "Plankton", ColorCode = "HGSW1244", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1244.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 25, ColorName = "Eucalytus Leaves", ColorCode = "HGSW1271", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1271.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 26, ColorName = "Talipot Palm", ColorCode = "HGSW1272", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1272.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 27, ColorName = "Paradox Green", ColorCode = "HGSW1273", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1273.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 28, ColorName = "Glowing Leaf", ColorCode = "HGSW1274", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1274.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 29, ColorName = "Galley Green", ColorCode = "HGSW1301", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1301.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 30, ColorName = "Green Escarpment", ColorCode = "HGSW1302", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1302.png" });

            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 31, ColorName = "Tropical Cay", ColorCode = "HGSW1303", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1303.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 32, ColorName = "Cotswold Green", ColorCode = "HGSW1303", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1303.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 33, ColorName = "Amalfi", ColorCode = "HGSW1341", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1341.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 34, ColorName = "Amidship", ColorCode = "HGSW1342", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1342.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 35, ColorName = "Blue Bicyle", ColorCode = "HGSW1343", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1343.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 36, ColorName = "Above the Waves", ColorCode = "HGSW1344", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1344.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 37, ColorName = "Delft Pottery", ColorCode = "HGSW1391", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1391.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 38, ColorName = "Vital Blue", ColorCode = "HGSW1392", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1392.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 39, ColorName = "Vintage Periwinkle", ColorCode = "HGSW1393", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1393.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 40, ColorName = "Pembroke Blue", ColorCode = "HGSW1394", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1394.png" });

            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 41, ColorName = "Tricorn Black", ColorCode = "HGSW1441", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1441.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 42, ColorName = "Raven Wing", ColorCode = "HGSW1442", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1442.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 43, ColorName = "Nevermore Grey", ColorCode = "HGSW1443", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1443.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 44, ColorName = "Nor'easter", ColorCode = "HGSW1444", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/HGSW1444.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 45, ColorName = "Night View", ColorCode = "4007-4C", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4007-4C.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 46, ColorName = "Smoky Pitch", ColorCode = "4007-4B", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4007-4B.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 47, ColorName = "Magnet Dapple", ColorCode = "4007-4A", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4007-4A.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 48, ColorName = "Muted Ebony", ColorCode = "4008-2C", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4008-2C.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 49, ColorName = "Almost Charcoal", ColorCode = "4008-2B", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4008-2B.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 50, ColorName = "", ColorCode = "", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/.png" });

            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 51, ColorName = "City Storms", ColorCode = "4008-2A", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4008-2A.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 52, ColorName = "Silver Fox", ColorCode = "4008-3C", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4008-3C.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 53, ColorName = "Lighthouse Shadows", ColorCode = "4008-3B", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4008-3B.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 54, ColorName = "Rising Tide", ColorCode = "4008-3A", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4008-3A.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 55, ColorName = "Cosmic Berry", ColorCode = "4001-10C", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4001-10C.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 56, ColorName = "Berries Galore", ColorCode = "4001-10B", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4001-10B.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 57, ColorName = "Plink", ColorCode = "4001-10A", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4001-10A.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 58, ColorName = "Lavender Quartz", ColorCode = "4001-9C", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4001-9C.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 59, ColorName = "Simply Lavender", ColorCode = "4001-9B", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4001-9B.png" });
            CollectionOfColorCode.Add(item: new ColorCodeModel() { Id = 40, ColorName = "Lavender Moon", ColorCode = "4001-9A", ColorCodeImage = @"/LowesKiosk;component/Images/SearchColor/4001-9A.png" });
        }

        public void SearchColorCode()
        {
            if (!string.IsNullOrWhiteSpace(ColorCodeSearch))
            {
                CollectionOfColorCodeSearch = CollectionOfColorCode.Where(x => x.ColorName.ToLower().Contains(ColorCodeSearch.ToLower())).ToObservableCollection();
            }
            else
            {
                CollectionOfColorCodeSearch = new ObservableCollection<ColorCodeModel>();
            }

            ColorCodeSearchVisibility = CollectionOfColorCodeSearch.Count() > 0 ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion

        #region Commands
        #region Main Command
        public ICommand MainCommand
        {
            get => new MvvmRelayCommand(DoMainCommand);
        }

        void DoMainCommand()
        {
            SwitchView("main");
        }
        #endregion

        #region Add More Command
        public ICommand AddMoreCommand
        {
            get => new MvvmRelayCommand(DoAddMoreCommand);
        }

        void DoAddMoreCommand()
        {
            SwitchView("addmore");
        }
        #endregion

        #region Color Search Command
        public ICommand ColorSearchCommand
        {
            get => new MvvmRelayCommand(DoColorSearchCommand);
        }

        void DoColorSearchCommand()
        {
            SwitchView("colorsearch");
        }
        #endregion

        #region Color List Command
        public ICommand ColorListCommand
        {
            get => new MvvmRelayCommand(DoColorListCommand);
        }

        void DoColorListCommand()
        {
            SwitchView("colorlist");
        }
        #endregion

        #region Main Product Command
        public ICommand MainProductCommand
        {
            get => new MvvmRelayCommand(DoMainProductCommand);
        }

        void DoMainProductCommand()
        {
            SwitchView("mainproduct");
        }
        #endregion

        #region Interior Command
        public ICommand InteriorCommand
        {
            get => new MvvmRelayCommand<object>(DoInteriorCommand);
        }

        void DoInteriorCommand(object value)
        {
            SelectedOrderMaster.ProductType = ConstantsHelper.Interior;
            SwitchView("interior");
        }
        #endregion

        #region Exterior Command
        public ICommand ExteriorCommand
        {
            get => new MvvmRelayCommand<object>(DoExteriorCommand);
        }

        void DoExteriorCommand(object value)
        {
            SelectedOrderMaster.ProductType = ConstantsHelper.Exterior;
            SwitchView("exterior");
        }
        #endregion

        #region Back To Main Product Command
        public ICommand BackToMainProductCommand
        {
            get => new MvvmRelayCommand(DoBackToMainProductCommand);
        }

        void DoBackToMainProductCommand()
        {
            SwitchView("mainproduct");
        }
        #endregion

        #region Sheen Command
        public ICommand SheenCommand
        {
            get => new MvvmRelayCommand<object>(DoSheenCommand);
        }

        void DoSheenCommand(object value)
        {
            SelectedOrderMaster.ProductName = value.ToString();
            SwitchView("sheen");
        }
        #endregion

        #region Back To Interior Or Exterior Command
        public ICommand BackToInteriorOrExteriorCommand
        {
            get => new MvvmRelayCommand(DoBackToInteriorOrExteriorCommand);
        }

        void DoBackToInteriorOrExteriorCommand()
        {
            if (LastView == "interior")
            {
                SwitchView("interior");
                return;
            }

            if (LastView == "exterior")
            {
                SwitchView("exterior");
                return;
            }

            SwitchView("mainproduct");
        }
        #endregion

        #region Bucket Size Command
        public ICommand BucketSizeCommand
        {
            get => new MvvmRelayCommand<object>(DoBucketSizeCommand);
        }

        void DoBucketSizeCommand(object value)
        {
            SelectedOrderMaster.Sheen = value.ToString();
            SwitchView("bucketsize");
        }
        #endregion

        #region Back To Sheen Command
        public ICommand BackToSheenCommand
        {
            get => new MvvmRelayCommand(DoBackToSheenCommand);
        }

        void DoBackToSheenCommand()
        {
            SwitchView("sheen");
        }
        #endregion

        #region Review Order Command
        public ICommand ReviewOrderCommand
        {
            get => new MvvmRelayCommand<object>(DoReviewOrderCommand);
        }

        void DoReviewOrderCommand(object value)
        {
            SelectedOrderMaster.BucketSize = value.ToString();
            SwitchView("revieworder");
        }
        #endregion

        #region Back To Bucket Size Command
        public ICommand BackToBucketSizeCommand
        {
            get => new MvvmRelayCommand(DoBackToBucketSizeCommand);
        }

        void DoBackToBucketSizeCommand()
        {
            CollectionOfOrderMaster.Remove(SelectedOrderMaster);
            SwitchView("bucketsize");
        }
        #endregion

        #region Quantity Changed Command
        public ICommand QuantityChangedCommand
        {
            get => new MvvmRelayCommand<object>(DoQuantityChangedCommand);
        }

        void DoQuantityChangedCommand(object value)
        {
            OrderMaster orderMaster = value as OrderMaster;
            if (orderMaster.Quantity == 0)
            {
                if (MessageBox.Show("Are you sure, you wnat to remove this item ?", "Are you sure", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    CollectionOfOrderMaster.Remove(orderMaster);

                    if (CollectionOfOrderMaster.Count == 0)
                    {
                        SwitchView("colorsearch");
                    }
                }
                else
                {
                    orderMaster.Quantity = 1;
                }
            }
        }
        #endregion

        #region Quantity Plus Command
        public ICommand QuantityPlusCommand
        {
            get => new MvvmRelayCommand<object>(DoQuantityPlusCommand);
        }

        void DoQuantityPlusCommand(object value)
        {
            OrderMaster orderMaster = value as OrderMaster;
            orderMaster.Quantity += 1;
        }

        #region Quantity Minus Command
        public ICommand QuantityMinusCommand
        {
            get => new MvvmRelayCommand<object>(DoQuantityMinusCommand);
        }

        void DoQuantityMinusCommand(object value)
        {
            OrderMaster orderMaster = value as OrderMaster;
            orderMaster.Quantity -= 1;
            if (orderMaster.Quantity == 0)
            {
                if (MessageBox.Show("Are you sure, you wnat to remove this item ?", "Are you sure", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    CollectionOfOrderMaster.Remove(orderMaster);

                    if (CollectionOfOrderMaster.Count == 0)
                    {
                        SwitchView("colorsearch");
                    }
                }
                else
                {
                    orderMaster.Quantity = 1;
                }
            }
        }
        #endregion
        #endregion

        #region Submit Order Command
        public ICommand SubmitOrderCommand
        {
            get => new MvvmRelayCommand(DoSubmitOrderCommand, CanSubmitOrderCommand);
        }

        void DoSubmitOrderCommand()
        {
            if (string.IsNullOrWhiteSpace(CustomerName))
            {
                MessageBox.Show("Please enter name!", "Enter name", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            //string body = "";
            //string toEmail = ConfigurationManager.AppSettings["ToEmail"];
            //SendEmail("Order placed by " + CustomerName, body, toEmail);

            SwitchView("thankyou");
        }

        bool CanSubmitOrderCommand()
        {
            return true;//string.IsNullOrWhiteSpace(CustomerName);
        }
        #endregion

        #region Thank You Command
        public ICommand ThankYouCommand
        {
            get => new MvvmRelayCommand(DoThankYouCommand);
        }
        void DoThankYouCommand()
        {
            SwitchView("main");
        }
        #endregion

        #endregion
    }
}
