﻿using System;
using System.Windows.Input;

namespace LowesKiosk.MvvmFramework
{
    public class MvvmRelayCommand
    : ICommand
    , IDisposable
    {
        private Func<bool> _canExecute;
        private Action _execute;
        public MvvmRelayCommand(Action execute)
            : this(execute, null)
        {
        }
        public MvvmRelayCommand(Action execute, Func<bool> canExecute)
        {
            _execute = execute;
            _canExecute = canExecute;
        }
        #region ICommand Members
        public event EventHandler CanExecuteChanged;
        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute();
        }
        public bool CanExecute()
        {
            return CanExecute(null);
        }
        public void Execute(object parameter)
        {
            if (CanExecute(parameter))
            {
                _execute();
            }
        }
        public void Execute()
        {
            Execute(null);
        }
        #endregion
        public void RaiseCanExecuteChanged()
        {
            var handler = CanExecuteChanged;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
        }
        #region IDisposable implementation
        public void Dispose()
        {
            Dispose(true);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                _execute = null;
                _canExecute = null;
            }
        }
        #endregion
    }
    public class MvvmRelayCommand<T>
    : ICommand
    , IDisposable
    {
        private Func<T, bool> _canExecute;
        private Action<T> _execute;
        public MvvmRelayCommand(Action<T> execute)
            : this(execute, null)
        {
        }
        public MvvmRelayCommand(Action<T> execute, Func<T, bool> canExecute)
        {
            _execute = execute;
            _canExecute = canExecute;
        }
        #region ICommand Members
        public event EventHandler CanExecuteChanged;
        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute((T)parameter);
        }
        public bool CanExecute()
        {
            return CanExecute(null);
        }
        public void Execute(object parameter)
        {
            if (CanExecute(parameter))
            {
                _execute((T)parameter);
            }
        }
        public void Execute()
        {
            Execute(null);
        }
        #endregion
        public void RaiseCanExecuteChanged()
        {
            var handler = CanExecuteChanged;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
        }
        #region IDisposable implementation
        public void Dispose()
        {
            Dispose(true);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                _execute = null;
                _canExecute = null;
            }
        }
        #endregion
    }
}