﻿using LowesKiosk.DataAccess.Helpers;
using LowesKiosk.ViewModels;
using System.Windows;

namespace LowesKiosk
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region Variables
        internal MainViewModel MainViewModel { get; }
        #endregion

        #region Ctor
        public MainWindow()
        {
            InitializeComponent();

            DbHelper dbHelper = new DbHelper();
            dbHelper.CreateDb();

            MainViewModel = new MainViewModel();
            DataContext = MainViewModel;
        }
        #endregion

        private void TitleBar_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            DragMove();
        }
    }
}
