﻿namespace LowesKiosk.Helpers
{
    public static class ConstantsHelper
    {
        //Product Type
        private static string interior = "Interior";
        public static string Interior { get => interior; set => interior = value; }
        private static string exterior = "Exterior";
        public static string Exterior { get => exterior; set => exterior = value; }

        //Interior Product Name
        private static string interior_Infinity = "Infinity";
        public static string Interior_Infinity { get => interior_Infinity; set => interior_Infinity = value; }
        private static string interior_Showcase = "Showcase";
        public static string Interior_Showcase { get => interior_Showcase; set => interior_Showcase = value; }
        private static string interior_Signature = "Signature";
        public static string Interior_Signature { get => interior_Signature; set => interior_Signature = value; }
        private static string interior_Ultra = "Ultra";
        public static string Interior_Ultra { get => interior_Ultra; set => interior_Ultra = value; }
        private static string interior_Simplicity = "Simplicity";
        public static string Interior_Simplicity { get => interior_Simplicity; set => interior_Simplicity = value; }
        private static string interior_2000 = "2000";
        public static string Interior_2000 { get => interior_2000; set => interior_2000 = value; }

        //Exterior Product Name
        private static string exterior_Infinity = "Infinity";
        public static string Exterior_Infinity { get => exterior_Infinity; set => exterior_Infinity = value; }
        private static string exterior_WeatherShield = "Weather Shield";
        public static string Exterior_WeatherShield { get => exterior_WeatherShield; set => exterior_WeatherShield = value; }
        private static string exterior_Durmax = "Durmax";
        public static string Exterior_Durmax { get => exterior_Durmax; set => exterior_Durmax = value; }
        private static string exterior_SeasonPlus = "Season Plus";
        public static string Exterior_SeasonPlus { get => exterior_SeasonPlus; set => exterior_SeasonPlus = value; }
        private static string exterior_SeasonFlex = "Season Flex";
        public static string Exterior_SeasonFlex { get => exterior_SeasonFlex; set => exterior_SeasonFlex = value; }
        private static string exterior_StormCoat = "Storm Coat";
        public static string Exterior_StormCoat { get => exterior_StormCoat; set => exterior_StormCoat = value; }

        //Sheen
        private static string sheen_Semigloss = "Semi Gloss";
        public static string Sheen_Semigloss { get => sheen_Semigloss; set => sheen_Semigloss = value; }
        private static string sheen_Satin = "Satin";
        public static string Sheen_Satin { get => sheen_Satin; set => sheen_Satin = value; }
        private static string sheen_Eggshell = "Eggshell";
        public static string Sheen_Eggshell { get => sheen_Eggshell; set => sheen_Eggshell = value; }
        private static string sheen_Flat = "Flat";
        public static string Sheen_Flat { get => sheen_Flat; set => sheen_Flat = value; }

        //Bucket Size
        private static string bucketsize_5Gallon = "5 Gallon";
        public static string Bucketsize_5Gallon { get => bucketsize_5Gallon; set => bucketsize_5Gallon = value; }
        private static string bucketsize_1Gallon = "1 Gallon";
        public static string Bucketsize_1Gallon { get => bucketsize_1Gallon; set => bucketsize_1Gallon = value; }
        private static string bucketsize_1Quart = "1 Quart";
        public static string Bucketsize_1Quart { get => bucketsize_1Quart; set => bucketsize_1Quart = value; }
    }
}
