﻿using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace LowesKiosk.Helpers
{
    public class TouchEnabledTextBox : TextBox
    {
        private Process _touchKeyboardProcess = null;
        string touchKeyboardPath = @"C:\Program Files\Common Files\Microsoft Shared\Ink\TabTip.exe";
        public TouchEnabledTextBox()
        {
            GotTouchCapture += TouchEnabledTextBox_GotTouchCapture;
            GotFocus += TouchEnabledTextBox_GotFocus;
            LostFocus += TouchEnabledTextBox_LostFocus;
            LostTouchCapture += TouchEnabledTextBox_LostTouchCapture;
        }

        private void TouchEnabledTextBox_LostTouchCapture(object sender, System.Windows.Input.TouchEventArgs e)
        {
            _touchKeyboardProcess = Process.Start(touchKeyboardPath);

            if (_touchKeyboardProcess != null)
            {
                _touchKeyboardProcess.Kill();
                _touchKeyboardProcess = null;
            }
        }

        private void TouchEnabledTextBox_GotFocus(object sender, System.Windows.RoutedEventArgs e)
        {
            _touchKeyboardProcess = Process.Start(touchKeyboardPath);
        }

        private void TouchEnabledTextBox_GotTouchCapture(object sender, System.Windows.Input.TouchEventArgs e)
        {
            _touchKeyboardProcess = Process.Start(touchKeyboardPath);
        }

        private void TouchEnabledTextBox_LostFocus(object sender, RoutedEventArgs eventArgs)
        {
            _touchKeyboardProcess = Process.Start(touchKeyboardPath);

            if (_touchKeyboardProcess != null)
            {
                _touchKeyboardProcess.Kill();
                _touchKeyboardProcess = null;
            }
        }
    }
}