﻿using LowesKiosk.DataModel;
using LowesKiosk.Helpers;
using System;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace LowesKiosk.Converters
{
    public class StringToSourceConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (targetType == typeof(ImageSource))
            {
                if (value is OrderMaster)
                {
                    string imgPath = "/LowesKiosk;component/Images/Interior_Infinity.png";
                    OrderMaster orderMaster = value as OrderMaster;
                    if (orderMaster.ProductType == ConstantsHelper.Interior)
                    {
                        if(orderMaster.ProductName == ConstantsHelper.Interior_Infinity)
                        {
                            imgPath = "/LowesKiosk;component/Images/Interior_Infinity.png";
                        }

                        if (orderMaster.ProductName == ConstantsHelper.Interior_Showcase)
                        {
                            imgPath = "/LowesKiosk;component/Images/Interior_Showcase.png";
                        }

                        if (orderMaster.ProductName == ConstantsHelper.Interior_Signature)
                        {
                            imgPath = "/LowesKiosk;component/Images/Interior_Signature.png";
                        }

                        if (orderMaster.ProductName == ConstantsHelper.Interior_Ultra)
                        {
                            imgPath = "/LowesKiosk;component/Images/Interior_Ultra.png";
                        }

                        if (orderMaster.ProductName == ConstantsHelper.Interior_Simplicity)
                        {
                            imgPath = "/LowesKiosk;component/Images/Interior_Simplicity.png";
                        }

                        if (orderMaster.ProductName == ConstantsHelper.Interior_2000)
                        {
                            imgPath = "/LowesKiosk;component/Images/Interior_2000.png";
                        }
                    }

                    if (orderMaster.ProductType == ConstantsHelper.Exterior)
                    {
                        if (orderMaster.ProductName == ConstantsHelper.Exterior_Infinity)
                        {
                            imgPath = "/LowesKiosk;component/Images/Exterior_Infinity.png";
                        }

                        if (orderMaster.ProductName == ConstantsHelper.Exterior_WeatherShield)
                        {
                            imgPath = "/LowesKiosk;component/Images/Exterior_WeatherShield.png";
                        }

                        if (orderMaster.ProductName == ConstantsHelper.Exterior_Durmax)
                        {
                            imgPath = "/LowesKiosk;component/Images/Exterior_Durmax.png";
                        }

                        if (orderMaster.ProductName == ConstantsHelper.Exterior_SeasonPlus)
                        {
                            imgPath = "/LowesKiosk;component/Images/Exterior_SeasonPlus.png";
                        }

                        if (orderMaster.ProductName == ConstantsHelper.Exterior_SeasonFlex)
                        {
                            imgPath = "/LowesKiosk;component/Images/Exterior_SeasonFlex.png";
                        }

                        if (orderMaster.ProductName == ConstantsHelper.Exterior_StormCoat)
                        {
                            imgPath = "/LowesKiosk;component/Images/Exterior_StormCoat.png";
                        }
                    }

                    return new BitmapImage(new Uri(imgPath, UriKind.RelativeOrAbsolute));
                }
            }
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
