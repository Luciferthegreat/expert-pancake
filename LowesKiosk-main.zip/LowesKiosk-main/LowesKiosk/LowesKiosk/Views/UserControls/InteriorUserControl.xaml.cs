﻿using LowesKiosk.Helpers;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;

namespace LowesKiosk.Views.UserControls
{
    /// <summary>
    /// Interaction logic for InteriorUserControl.xaml
    /// </summary>
    public partial class InteriorUserControl : UserControl
    {
        #region Variables
        Storyboard sbMoveToTrip;
        Storyboard sbMoveToTripCancel;

        Storyboard callToHelpSbMoveToTrip;
        Storyboard callToHelpSbMoveToTripCancel;
        #endregion

        #region Ctor
        public InteriorUserControl()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        private void PromptDetailDialog()
        {
            if (sbMoveToTrip != null)
                sbMoveToTrip.Stop();
            if (sbMoveToTripCancel != null)
                sbMoveToTripCancel.Stop();
            //Showing dialog animation
            sbMoveToTrip = Resources["PromptDetail"] as Storyboard;
            sbMoveToTrip.Begin();
        }

        private void ClosePromptDetail()
        {
            if (sbMoveToTripCancel != null)
                sbMoveToTripCancel.Stop();
            //Hiding dialog animation
            sbMoveToTripCancel = this.Resources["ClosePromptDetail"] as Storyboard;
            sbMoveToTripCancel.Begin();
        }

        private void CallToHelpPromptDetailDialog()
        {
            if (callToHelpSbMoveToTrip != null)
                callToHelpSbMoveToTrip.Stop();
            if (callToHelpSbMoveToTripCancel != null)
                callToHelpSbMoveToTripCancel.Stop();
            //Showing dialog animation
            callToHelpSbMoveToTrip = Resources["CallToHelpPromptDetail"] as Storyboard;
            callToHelpSbMoveToTrip.Begin();
        }

        private void CallToHelpClosePromptDetail()
        {
            if (callToHelpSbMoveToTripCancel != null)
                callToHelpSbMoveToTripCancel.Stop();
            //Hiding dialog animation
            callToHelpSbMoveToTripCancel = this.Resources["CallToHelpClosePromptDetail"] as Storyboard;
            callToHelpSbMoveToTripCancel.Begin();
        }

        #endregion

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            tbSelectedName.Text = ConstantsHelper.Interior_Infinity;
            image.Source = new BitmapImage(new Uri(@"/LowesKiosk;component/Images/infinity-info.png", UriKind.Relative));
            PromptDetailDialog();
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            tbSelectedName.Text = ConstantsHelper.Interior_Showcase;
            image.Source = new BitmapImage(new Uri(@"/LowesKiosk;component/Images/showcase-info.png", UriKind.Relative));
            PromptDetailDialog();
        }

        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            tbSelectedName.Text = ConstantsHelper.Interior_Signature;
            image.Source = new BitmapImage(new Uri(@"/LowesKiosk;component/Images/signature-info.png", UriKind.Relative));
            PromptDetailDialog();
        }

        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            tbSelectedName.Text = ConstantsHelper.Interior_Ultra;
            image.Source = new BitmapImage(new Uri(@"/LowesKiosk;component/Images/untra-info.png", UriKind.Relative));
            PromptDetailDialog();
        }

        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            tbSelectedName.Text = ConstantsHelper.Interior_Simplicity;
            image.Source = new BitmapImage(new Uri(@"/LowesKiosk;component/Images/simplicty-info.png", UriKind.Relative));
            PromptDetailDialog();
        }

        private void btn6_Click(object sender, RoutedEventArgs e)
        {
            tbSelectedName.Text = ConstantsHelper.Interior_2000;
            image.Source = new BitmapImage(new Uri(@"/LowesKiosk;component/Images/2000-info.png", UriKind.Relative));
            PromptDetailDialog();
        }

        private void CallToHelp_Click(object sender, RoutedEventArgs e)
        {
            CallToHelpPromptDetailDialog();
        }

        private void image_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            //ClosePromptDetail();
        }
        private void CallToHelp_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            CallToHelpClosePromptDetail();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            ClosePromptDetail();
        }

        private void btnCloseHelp_Click(object sender, RoutedEventArgs e)
        {
            CallToHelpClosePromptDetail();
        }
    }
}
