﻿using LowesKiosk.ViewModels;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace LowesKiosk.Views.UserControls
{
    /// <summary>
    /// Interaction logic for ReviewOrderUserControl.xaml
    /// </summary>
    public partial class ReviewOrderUserControl : UserControl
    {
        #region Variables
        Storyboard sbMoveToTrip;
        Storyboard sbMoveToTripCancel;

        Storyboard callToHelpSbMoveToTrip;
        Storyboard callToHelpSbMoveToTripCancel;

        #endregion

        #region Ctor
        public ReviewOrderUserControl()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods
        private void PromptDetailDialog()
        {
            if (sbMoveToTrip != null)
                sbMoveToTrip.Stop();
            if (sbMoveToTripCancel != null)
                sbMoveToTripCancel.Stop();
            

            //Showing dialog animation
            sbMoveToTrip = Resources["PromptDetail"] as Storyboard;
            sbMoveToTrip.Begin();
        }

        private void ClosePromptDetail()
        {
            if (sbMoveToTripCancel != null)
                sbMoveToTripCancel.Stop();
            //Hiding dialog animation
            sbMoveToTripCancel = this.Resources["ClosePromptDetail"] as Storyboard;
            sbMoveToTripCancel.Begin();
        }

        private void CallToHelpPromptDetailDialog()
        {
            if (callToHelpSbMoveToTrip != null)
                callToHelpSbMoveToTrip.Stop();
            if (callToHelpSbMoveToTripCancel != null)
                callToHelpSbMoveToTripCancel.Stop();
            //Showing dialog animation
            callToHelpSbMoveToTrip = Resources["CallToHelpPromptDetail"] as Storyboard;
            callToHelpSbMoveToTrip.Begin();
        }

        private void CallToHelpClosePromptDetail()
        {
            if (callToHelpSbMoveToTripCancel != null)
                callToHelpSbMoveToTripCancel.Stop();
            //Hiding dialog animation
            callToHelpSbMoveToTripCancel = this.Resources["CallToHelpClosePromptDetail"] as Storyboard;
            callToHelpSbMoveToTripCancel.Begin();
        }

        #endregion

        private void btnSubmit_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            PromptDetailDialog();
        }

        private void image_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            ClosePromptDetail();
            var mainViewModel = DataContext as MainViewModel;
            mainViewModel?.MainCommand.Execute(null);
        }

        private void btnClose_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            ClosePromptDetail();
        }
        private void CallToHelp_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            CallToHelpPromptDetailDialog();
        }
        private void CallToHelp_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            CallToHelpClosePromptDetail();
        }

        private void btnCloseHelp_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            CallToHelpClosePromptDetail();
        }
    }
}
