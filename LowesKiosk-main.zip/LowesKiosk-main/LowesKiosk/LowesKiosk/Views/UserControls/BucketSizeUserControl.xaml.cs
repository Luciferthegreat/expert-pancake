﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LowesKiosk.Views.UserControls
{
    /// <summary>
    /// Interaction logic for BucketSizeUserControl.xaml
    /// </summary>
    public partial class BucketSizeUserControl : UserControl
    {
        #region Variables

        Storyboard callToHelpSbMoveToTrip;
        Storyboard callToHelpSbMoveToTripCancel;
        #endregion

        public BucketSizeUserControl()
        {
            InitializeComponent();
        }

        #region Methods
        private void CallToHelpPromptDetailDialog()
        {
            if (callToHelpSbMoveToTrip != null)
                callToHelpSbMoveToTrip.Stop();
            if (callToHelpSbMoveToTripCancel != null)
                callToHelpSbMoveToTripCancel.Stop();
            //Showing dialog animation
            callToHelpSbMoveToTrip = Resources["CallToHelpPromptDetail"] as Storyboard;
            callToHelpSbMoveToTrip.Begin();
        }

        private void CallToHelpClosePromptDetail()
        {
            if (callToHelpSbMoveToTripCancel != null)
                callToHelpSbMoveToTripCancel.Stop();
            //Hiding dialog animation
            callToHelpSbMoveToTripCancel = this.Resources["CallToHelpClosePromptDetail"] as Storyboard;
            callToHelpSbMoveToTripCancel.Begin();
        }

        #endregion

        private void CallToHelp_Click(object sender, RoutedEventArgs e)
        {
            CallToHelpPromptDetailDialog();
        }
        private void CallToHelp_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            CallToHelpClosePromptDetail();
        }

        private void btnCloseHelp_Click(object sender, RoutedEventArgs e)
        {
            CallToHelpClosePromptDetail();
        }
    }
}
