﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace LowesKiosk.Views.UserControls
{
    /// <summary>
    /// Interaction logic for BrowserUserControl.xaml
    /// </summary>
    public partial class BrowserUserControl : UserControl
    {
        public BrowserUserControl()
        {
            InitializeComponent();
            Loaded += BrowserUserControl_Loaded;
        }

        private void BrowserUserControl_Loaded(object sender, RoutedEventArgs e)
        {
            //wbControl.Navigate(new Uri("https://xd.adobe.com/view/a44375ea-beb8-4d16-93a8-665ad30688a9-f110/"));
            wbControl.Navigate("https://www.google.com/");

            wbControl.Loaded += delegate
            {
                wbControl.Navigate(new Uri("https://www.google.com/"));
            };
        }
    }
}
