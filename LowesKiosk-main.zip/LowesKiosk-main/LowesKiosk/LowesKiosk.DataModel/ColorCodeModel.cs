﻿namespace LowesKiosk.DataModel
{
    public class ColorCodeModel : BaseModel
    {
        private int? _id;
        public int? Id
        {
            get { return _id; }
            set { _id = value; OnPropertyChanged("Id"); }
        }

        private string _colorName;
        public string ColorName
        {
            get { return _colorName; }
            set { _colorName = value; OnPropertyChanged("ColorName"); }
        }

        private string _colorCode;
        public string ColorCode
        {
            get { return _colorCode; }
            set { _colorCode = value; OnPropertyChanged("ColorCode"); }
        }

        private string _colorCodeImage;
        public string ColorCodeImage
        {
            get { return _colorCodeImage; }
            set { _colorCodeImage = value; OnPropertyChanged("ColorCodeImage"); }
        }
    }
}
