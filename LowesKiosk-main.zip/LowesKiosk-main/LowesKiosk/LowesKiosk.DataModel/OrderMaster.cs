﻿using System;

namespace LowesKiosk.DataModel
{
    public class OrderMaster : BaseModel
    {
        private int? _id;
        public int? Id
        {
            get { return _id; }
            set { _id = value; OnPropertyChanged("Id"); }
        }

        private string _productType;
        public string ProductType
        {
            get { return _productType; }
            set { _productType = value; OnPropertyChanged("ProductType"); }
        }

        private string _productName;
        public string ProductName
        {
            get { return _productName; }
            set { _productName = value; OnPropertyChanged("ProductName"); }
        }

        private string _sheen;
        public string Sheen
        {
            get { return _sheen; }
            set { _sheen = value; OnPropertyChanged("Sheen"); }
        }

        private string _bucketSize;
        public string BucketSize
        {
            get { return _bucketSize; }
            set { _bucketSize = value; OnPropertyChanged("BucketSize"); }
        }

        private int _quantity;
        public int Quantity
        {
            get { return _quantity; }
            set { _quantity = value; OnPropertyChanged("Quantity"); }
        }

        private string _colorName;
        public string ColorName
        {
            get { return _colorName; }
            set { _colorName = value; OnPropertyChanged("ColorName"); }
        }

        private DateTime? _orderDate;
        public DateTime? OrderDate
        {
            get { return _orderDate; }
            set { _orderDate = value; OnPropertyChanged("OrderDate"); }
        }
    }
}
