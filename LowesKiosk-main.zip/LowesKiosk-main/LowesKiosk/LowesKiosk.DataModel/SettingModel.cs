﻿namespace LowesKiosk.DataModel
{
    public class SettingModel : BaseModel
    {
        #region Properties
        private string _fromEmail;
        public string FromEmail
        {
            get => _fromEmail;
            set { _fromEmail = value; OnPropertyChanged("FromEmail"); }
        }

        private string _serverName;
        public string ServerName
        {
            get => _serverName;
            set { _serverName = value; OnPropertyChanged("ServerName"); }
        }

        private int _port;
        public int Port
        {
            get => _port;
            set { _port = value; OnPropertyChanged("Port"); }
        }

        private string _password;
        public string Password
        {
            get => _password;
            set { _password = value; OnPropertyChanged("Password"); }
        }
        #endregion
    }
}