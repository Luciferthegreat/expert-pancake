﻿using System;
using System.Collections.Generic;
using VMS.DataModels.Models;
using Xunit;
namespace VMS.DataAccess.Test
{

    public class DeviceRepositoryTest
    {
        [Fact]
        public void GetDevicesTestPositive()
        {
            DeviceRepository deviceRepo = new DeviceRepository();
            List<DeviceMaster> devices = deviceRepo.GetAllDevice();

            int deviceCount = devices.Count;

            Assert.NotEqual(0, deviceCount);

        }


        [Fact]
        public void InsertDeviceTestPositive()
        {
            DeviceRepository deviceRepo = new DeviceRepository();
            bool insertSuccess = deviceRepo.InsertDevice(new DeviceMaster() { DeviceName = "192.168.1.1", DeviceAddress = "8080", IsEnabled = true, DeviceUpdateDate = DateTime.Now });

            Assert.NotEqual(false, insertSuccess);

        }
    }
}
