﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.DataModels.CommonModels
{
    public class MappingClass
    {
        private int _CardDeviceMappingID;
        public int CardDeviceMappingID
        {
            get { return _CardDeviceMappingID; }
            set { _CardDeviceMappingID = value; }
        }

        //Module
        private int _ModuleId;
        public int ModuleId
        {
            get { return _ModuleId; }
            set { _ModuleId = value; }
        }

        private string _ModuleName;
        public string ModuleName
        {
            get { return _ModuleName; }
            set { _ModuleName = value; }
        }

        private string _ModuleIP;
        public string ModuleIP
        {
            get { return _ModuleIP; }
            set { _ModuleIP = value; }
        }

        private string _ModulePort;
        public string ModulePort
        {
            get { return _ModulePort; }
            set { _ModulePort = value; }
        }

        private string _ModulePassword;
        public string ModulePassword
        {
            get { return _ModulePassword; }
            set { _ModulePassword = value; }
        }

        private int _ModuleTimeOut;
        public int ModuleTimeOut
        {
            get { return _ModuleTimeOut; }
            set { _ModuleTimeOut = value; }
        }

        private bool? _ModuleIsEnabled;
        public bool? ModuleIsEnabled
        {
            get { return _ModuleIsEnabled; }
            set { _ModuleIsEnabled = value; }
        }

        private DateTime _ModuleUpdateDate;
        public DateTime ModuleUpdateDate
        {
            get { return _ModuleUpdateDate; }
            set { _ModuleUpdateDate = value; }
        }
        //Device
        private int _DeviceID;
        public int DeviceID
        {
            get { return _DeviceID; }
            set { _DeviceID = value; }
        }

        private string _DeviceName;
        public string DeviceName
        {
            get { return _DeviceName; }
            set { _DeviceName = value; }
        }

        private string _DeviceAddress;
        public string DeviceAddress
        {
            get { return _DeviceAddress; }
            set { _DeviceAddress = value; }
        }

        private bool? _DeviceIsEnabled;
        public bool? DeviceIsEnabled
        {
            get { return _DeviceIsEnabled; }
            set { _DeviceIsEnabled = value; }
        }

        private DateTime? _DeviceUpdateDate;
        public DateTime? DeviceUpdateDate
        {
            get { return _DeviceUpdateDate; }
            set { _DeviceUpdateDate = value; }
        }
        //Card
        private int _CardPrimaryID;
        public int CardPrimaryID
        {
            get { return _CardPrimaryID; }
            set { _CardPrimaryID = value; }
        }

        private string _CardID;
        public string CardID
        {
            get { return _CardID; }
            set { _CardID = value; }
        }

        private string _CardNumber;
        public string CardNumber
        {
            get { return _CardNumber; }
            set { _CardNumber = value; }
        }

        private string _UserName;
        public string UserName
        {
            get { return _UserName; }
            set { _UserName = value; }
        }

        private DateTime? _AccessStartDate;
        public DateTime? AccessStartDate
        {
            get { return _AccessStartDate; }
            set { _AccessStartDate = value; }
        }

        private DateTime? _AccessEndDate;
        public DateTime? AccessEndDate
        {
            get { return _AccessEndDate; }
            set { _AccessEndDate = value; }
        }

        private string _Purpose;
        public string Purpose
        {
            get { return _Purpose; }
            set { _Purpose = value; }
        }

        private string _WhomeToMeet;
        public string WhomeToMeet
        {
            get { return _WhomeToMeet; }
            set { _WhomeToMeet = value; }
        }

        private string _Photo;
        public string Photo
        {
            get { return _Photo; }
            set { _Photo = value; }
        }

        private string _Department;
        public string Department
        {
            get { return _Department; }
            set { _Department = value; }
        }

        private string _ExtraDetails;
        public string ExtraDetails
        {
            get { return _ExtraDetails; }
            set { _ExtraDetails = value; }
        }

        private string _Address;
        public string Address
        {
            get { return _Address; }
            set { _Address = value; }
        }

        private string _ContactNo;
        public string ContactNo
        {
            get { return _ContactNo; }
            set { _ContactNo = value; }
        }

        private string _IdProofType;
        public string IdProofType
        {
            get { return _IdProofType; }
            set { _IdProofType = value; }
        }

        private string _IdProofNumber;
        public string IdProofNumber
        {
            get { return _IdProofNumber; }
            set { _IdProofNumber = value; }
        }

        private DateTime _CardUpdateDate;
        public DateTime CardUpdateDate
        {
            get { return _CardUpdateDate; }
            set { _CardUpdateDate = value; }
        }
    }
}
