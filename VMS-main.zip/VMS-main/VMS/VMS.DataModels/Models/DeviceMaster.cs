﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.DataModels.Models
{
    public class DeviceMaster
    {
        private int _DeviceID;
        public int DeviceID
        {
            get { return _DeviceID; }
            set { _DeviceID = value; }
        }

        private int _ModuleId;
        public int ModuleId
        {
            get { return _ModuleId; }
            set { _ModuleId = value; }
        }

        private string _ModuleName;
        public string ModuleName
        {
            get { return _ModuleName; }
            set { _ModuleName = value; }
        }

        private string _DeviceName;
        public string DeviceName
        {
            get { return _DeviceName; }
            set { _DeviceName = value; }
        }

        private string _DeviceAddress;
        public string DeviceAddress
        {
            get { return _DeviceAddress; }
            set { _DeviceAddress = value; }
        }

        private bool? _IsEnabled;
        public bool? IsEnabled
        {
            get { return _IsEnabled; }
            set { _IsEnabled = value; }
        }

        private DateTime? _DeviceUpdateDate;
        public DateTime? DeviceUpdateDate
        {
            get { return _DeviceUpdateDate; }
            set { _DeviceUpdateDate = value; }
        }

        private Int16 _DeviceNo;
        public Int16 DeviceNo
        {
            get { return _DeviceNo; }
            set { _DeviceNo = value; }
        }
    }
}
