﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.DeviceAccess;

namespace VMS.DataModels.Models
{
    public class ModuleMaster : BaseModel
    {

        #region Variables
        public event EventHandlers.EventReceivedEventHandler OnEventReceived;
        public event EventHandlers.ErrorOccuredEventHandler OnErrorOccured;

        #endregion

        #region Ctor / Dtor
        public ModuleMaster()
        {
            this.ModulePort = "4370";
            this.TimeOut = 2000;
            this.Password = string.Empty;
            this.IsEnabled = true;
        }

        ~ModuleMaster()
        {
            if (DeviceAdapter.IsDeviceConnected)
            {
                this.DeviceAdapter.DisconnectDevice();
            }
            this._device = null;
        }
        #endregion

        #region Properties
        private int _ModuleId;
        public int ModuleId
        {
            get { return _ModuleId; }
            set { _ModuleId = value; }
        }

        private string _ModuleName;
        public string ModuleName
        {
            get { return _ModuleName; }
            set { _ModuleName = value; }
        }

        private string _ModuleIP;
        public string ModuleIP
        {
            get { return _ModuleIP; }
            set { _ModuleIP = value; }
        }

        private string _ModulePort;
        public string ModulePort
        {
            get { return _ModulePort; }
            set { _ModulePort = value; }
        }

        private string _Password;
        public string Password
        {
            get { return _Password; }
            set { _Password = value; }
        }

        private int _TimeOut;
        public int TimeOut
        {
            get { return _TimeOut; }
            set { _TimeOut = value; }
        }

        private bool? _IsEnabled;
        public bool? IsEnabled
        {
            get { return _IsEnabled; }
            set { _IsEnabled = value; }
        }

        public bool IsDeviceConnected
        {
            get
            {
                return DeviceAdapter.IsDeviceConnected;
            }
        }

        private DateTime? _ModuleUpdateDate;
        public DateTime? ModuleUpdateDate
        {
            get { return _ModuleUpdateDate; }
            set { _ModuleUpdateDate = value; }
        }

        private BridgeDevice _device;
        public BridgeDevice DeviceAdapter
        {
            get
            {
                if (_device == null)
                {
                    _device = new BridgeDevice();
                    _device.OnEventReceived += _device_OnEventReceived;
                    _device.OnErrorOccured += _device_OnErrorOccured;
                }
                return _device;
            }
        }

        void _device_OnErrorOccured(Exception errorMessage)
        {
            if (this.OnErrorOccured != null)
                this.OnErrorOccured(errorMessage);
        }

        void _device_OnEventReceived(DeviceEvent devEvent)
        {
            if (this.OnEventReceived != null)
            {
                if (devEvent != null)
                {
                    devEvent.ModuleDBID = this.ModuleId;
                }
                this.OnEventReceived(devEvent);
            }
        }
        #endregion


    }
}
