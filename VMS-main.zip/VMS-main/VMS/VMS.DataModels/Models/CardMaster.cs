﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.DataModels.Models
{
    public class CardMaster
    {
        private int _CardPrimaryID;
        public int CardPrimaryID
        {
            get { return _CardPrimaryID; }
            set { _CardPrimaryID = value; }
        }

        private string _CardID;
        public string CardID
        {
            get { return _CardID; }
            set { _CardID = value; }
        }

        private string _CardNumber;
        public string CardNumber
        {
            get { return _CardNumber; }
            set { _CardNumber = value; }
        }

        private string _UserName;
        public string UserName
        {
            get { return _UserName; }
            set { _UserName = value; }
        }

        private DateTime? _AccessStartDate;
        public DateTime? AccessStartDate
        {
            get { return _AccessStartDate; }
            set { _AccessStartDate = value; }
        }

        private DateTime? _AccessEndDate;
        public DateTime? AccessEndDate
        {
            get { return _AccessEndDate; }
            set { _AccessEndDate = value; }
        }

        private string _Purpose;
        public string Purpose
        {
            get { return _Purpose; }
            set { _Purpose = value; }
        }

        private string _WhomeToMeet;
        public string WhomeToMeet
        {
            get { return _WhomeToMeet; }
            set { _WhomeToMeet = value; }
        }

        private string _Photo;
        public string Photo
        {
            get { return _Photo; }
            set { _Photo = value; }
        }

        private string _Department;
        public string Department
        {
            get { return _Department; }
            set { _Department = value; }
        }

        private string _ExtraDetails;
        public string ExtraDetails
        {
            get { return _ExtraDetails; }
            set { _ExtraDetails = value; }
        }

        private string _Address;
        public string Address
        {
            get { return _Address; }
            set { _Address = value; }
        }

        private string _ContactNo;
        public string ContactNo
        {
            get { return _ContactNo; }
            set { _ContactNo = value; }
        }

        private string _IdProofType;
        public string IdProofType
        {
            get { return _IdProofType; }
            set { _IdProofType = value; }
        }

        private string _IdProofNumber;
        public string IdProofNumber
        {
            get { return _IdProofNumber; }
            set { _IdProofNumber = value; }
        }

        private DateTime? _CardUpdateDate;
        public DateTime? CardUpdateDate
        {
            get { return _CardUpdateDate; }
            set { _CardUpdateDate = value; }
        }
    }
}
