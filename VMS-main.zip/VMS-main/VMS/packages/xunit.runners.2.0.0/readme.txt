The xunit.runners package has been retired.

For the console runner, install xunit.runner.console.
For the MSBuild runner, install xunit.runner.msbuild.

You can safely uninstall xunit.runners now.
