﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.DataAccess.Helpers
{
    public class Enums
    {
        public enum ReportTypes
        {
            Date = 1,
            Card,
            Device,
            VisitorContactNo,
            VisitorName,
        };
    }
}
