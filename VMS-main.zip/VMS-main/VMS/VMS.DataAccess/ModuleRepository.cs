﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.DataModels.Models;

namespace VMS.DataAccess
{
    public class ModuleRepository
    {
        #region Properites
        #endregion

        #region Ctor
        #endregion

        #region Methods
        public List<ModuleMaster> GetAllModule()
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<ModuleMaster> _ListOfModuleMaster = _DbManager
                   .SetCommand(@"SELECT ModuleId, ModuleName, ModuleIP, ModulePort, Password, TimeOut, IsEnable, ModuleUpdateDate
                                FROM MasterModule").ExecuteList<ModuleMaster>();

                    return _ListOfModuleMaster;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public List<ModuleMaster> GetModuleByModuleId(long p_ModuleId)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<ModuleMaster> _ListOfModuleMaster = _DbManager
                   .SetCommand(@"SELECT ModuleId, ModuleName, ModuleIP, ModulePort, Password, TimeOut, IsEnable, ModuleUpdateDate
                            FROM MasterModule WHERE ModuleId = @ModuleId",
                    _DbManager.Parameter("@ModuleId", p_ModuleId)).ExecuteList<ModuleMaster>();

                    return _ListOfModuleMaster;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public List<ModuleMaster> GetModuleByNameAndIp(ModuleMaster p_ModuleMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<ModuleMaster> _ListOfModuleMaster;
                    if (p_ModuleMaster.ModuleId == 0)
                    {
                        _ListOfModuleMaster = _DbManager
                       .SetCommand(@"SELECT ModuleId, ModuleName, ModuleIP, ModulePort, Password, TimeOut, IsEnable, ModuleUpdateDate
                                FROM MasterModule WHERE ModuleName = @ModuleName AND ModuleIP = @ModuleIP",
                                    _DbManager.Parameter("@ModuleName", p_ModuleMaster.ModuleName.Trim()),
                                    _DbManager.Parameter("@ModuleIP", p_ModuleMaster.ModuleIP.Trim())).ExecuteList<ModuleMaster>();
                    }
                    else
                    {
                        _ListOfModuleMaster = _DbManager
                       .SetCommand(@"SELECT ModuleId, ModuleName, ModuleIP, ModulePort, Password, TimeOut, IsEnable, ModuleUpdateDate
                                FROM MasterModule WHERE ModuleName = @ModuleName AND ModuleIP = @ModuleIP AND ModuleId != @ModuleId",
                                    _DbManager.Parameter("@ModuleName", p_ModuleMaster.ModuleName.Trim()),
                                    _DbManager.Parameter("@ModuleIP", p_ModuleMaster.ModuleIP.Trim()),
                                    _DbManager.Parameter("@ModuleId", p_ModuleMaster.ModuleId)).ExecuteList<ModuleMaster>();
                    }
                    return _ListOfModuleMaster;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public bool InsertModule(ModuleMaster p_ModuleMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {

                    int retValue = _DbManager.SetCommand(@"INSERT INTO MasterModule (ModuleName, ModuleIP, ModulePort, Password, TimeOut, IsEnable, ModuleUpdateDate)
                                    VALUES (@ModuleName, @ModuleIP, @ModulePort, @Password, @TimeOut, @IsEnabled, @ModuleUpdateDate)",
                                         _DbManager.Parameter("@ModuleName", p_ModuleMaster.ModuleName),
                                         _DbManager.Parameter("@ModuleIP", p_ModuleMaster.ModuleIP),
                                         _DbManager.Parameter("@ModulePort", p_ModuleMaster.ModulePort),
                                         _DbManager.Parameter("@Password", p_ModuleMaster.Password),
                                         _DbManager.Parameter("@TimeOut", p_ModuleMaster.TimeOut),
                                         _DbManager.Parameter("@IsEnabled", p_ModuleMaster.IsEnabled),
                                         _DbManager.Parameter("@ModuleUpdateDate", p_ModuleMaster.ModuleUpdateDate))
                         .ExecuteNonQuery();

                    return (retValue > 0);
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void UpdateModule(ModuleMaster p_ModuleMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    _DbManager.SetCommand(@"UPDATE MasterModule
                                          SET ModuleName=@ModuleName, ModuleIP=@ModuleIP, ModulePort=@ModulePort, 
                                          Password=@Password, TimeOut=@TimeOut, IsEnable=@IsEnabled, ModuleUpdateDate=@ModuleUpdateDate
                                          WHERE ModuleId=@ModuleId",
                                          _DbManager.Parameter("@ModuleName", p_ModuleMaster.ModuleName),
                                         _DbManager.Parameter("@ModuleIP", p_ModuleMaster.ModuleIP),
                                         _DbManager.Parameter("@ModulePort", p_ModuleMaster.ModulePort),
                                         _DbManager.Parameter("@Password", p_ModuleMaster.Password),
                                         _DbManager.Parameter("@TimeOut", p_ModuleMaster.TimeOut),
                                         _DbManager.Parameter("@IsEnabled", p_ModuleMaster.IsEnabled),
                                         _DbManager.Parameter("@ModuleUpdateDate", p_ModuleMaster.ModuleUpdateDate),
                                          _DbManager.Parameter("@ModuleId", p_ModuleMaster.ModuleId))
                     .ExecuteNonQuery();
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void DeleteModule(ModuleMaster p_ModuleMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    _DbManager.SetCommand(@"DELETE FROM MasterModule WHERE ModuleId=@ModuleId",
                                _DbManager.Parameter("@ModuleId", p_ModuleMaster.ModuleId))
                             .ExecuteNonQuery();
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void InsertOrUpdateModule(ModuleMaster p_ModuleMaster)
        {
            if (p_ModuleMaster.ModuleId != 0)
            {
                UpdateModule(p_ModuleMaster);
            }
            else
            {
                InsertModule(p_ModuleMaster);
            }
        }
        #endregion
    }
}
