﻿using BLToolkit.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.DataModels.Models;

namespace VMS.DataAccess
{
    public class EventsRepository
    {
        #region Properites
        #endregion

        #region Ctor
        #endregion

        #region Methods
        public List<LiveEvent> GetAllEvents()
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<LiveEvent> _ListOfEvents = _DbManager
                   .SetCommand(@"SELECT EventID, ModuleId, ModuleName, ModuleIP, ModulePort, Password, TimeOut, IsEnable, ModuleUpdateDate,
                                DeviceID, ModuleId, DeviceName, DeviceAddress, IsEnabled, DeviceUpdateDate, DeviceNo,
                                CardPrimaryID, CardID, CardNumber, UserName, AccessStartDate, AccessEndDate, Purpose, WhomeToMeet, Photo, Department, ExtraDetails, Address, ContactNo, IdProofType, IdProofNumber, CardUpdateDate 
                                FROM Events").ExecuteList<LiveEvent>();

                    return _ListOfEvents;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }



        public void InsertLiveEvent(LiveEvent p_EventsClass)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {

                    _DbManager.SetCommand(@"INSERT INTO Events (ModuleId, ModuleName, ModuleIP, ModulePort, ModulePassword, ModuleTimeOut, ModuleIsEnabled, ModuleUpdateDate,
                                            DeviceID, DeviceName, DeviceAddress, DeviceIsEnabled, DeviceUpdateDate, DeviceNo,
                                            CardPrimaryID, CardID, CardNumber, UserName, AccessStartDate, AccessEndDate, Purpose, WhomeToMeet, Photo, Department, ExtraDetails, CardAddress, ContactNo, IdProofType, IdProofNumber, CardUpdateDate)
                                            VALUES (@EventID, @ModuleId, @ModuleName, @ModuleIP, @ModulePort, @ModulePassword, @ModuleTimeOut, @ModuleIsEnabled, @ModuleUpdateDate,
                                            @DeviceId, @DeviceName, @DeviceAddress, @DeviceIsEnabled, @DeviceUpdateDate, @DeviceNo
                                            @CardPrimaryID, @CardID, @CardNumber, @UserName, @AccessStartDate, @AccessEndDate, @Purpose, @WhomeToMeet, @Photo, @Department, @ExtraDetails, @CardAddress, @ContactNo, @IdProofType, @IdProofNumber, @CardUpdateDate)",
                                        _DbManager.Parameter("@ModuleId", p_EventsClass.ModuleId),
                                        _DbManager.Parameter("@ModuleName", p_EventsClass.ModuleName),
                                        _DbManager.Parameter("@ModuleIP", p_EventsClass.ModuleIP),
                                        _DbManager.Parameter("@ModulePort", p_EventsClass.ModulePort),
                                        _DbManager.Parameter("@ModulePassword", p_EventsClass.ModulePassword),
                                        _DbManager.Parameter("@ModuleTimeOut", p_EventsClass.ModuleTimeOut),
                                        _DbManager.Parameter("@ModuleIsEnabled", p_EventsClass.ModuleIsEnabled),
                                        _DbManager.Parameter("@ModuleUpdateDate", p_EventsClass.ModuleUpdateDate),

                                        _DbManager.Parameter("@DeviceId", p_EventsClass.DeviceId),
                                        _DbManager.Parameter("@DeviceName", p_EventsClass.DeviceName),
                                        _DbManager.Parameter("@DeviceAddress", p_EventsClass.DeviceAddress),
                                        _DbManager.Parameter("@DeviceIsEnabled", p_EventsClass.DeviceIsEnabled),
                                        _DbManager.Parameter("@DeviceUpdateDate", p_EventsClass.DeviceUpdateDate),
                                        _DbManager.Parameter("@DeviceNo", p_EventsClass.DeviceNo),

                                        _DbManager.Parameter("@CardPrimaryID", p_EventsClass.CardPrimaryID),
                                        _DbManager.Parameter("@CardID", p_EventsClass.CardID),
                                        _DbManager.Parameter("@CardNumber", p_EventsClass.CardNumber),
                                        _DbManager.Parameter("@UserName", p_EventsClass.UserName),
                                        _DbManager.Parameter("@AccessStartDate", p_EventsClass.AccessStartDate),
                                        _DbManager.Parameter("@AccessEndDate", p_EventsClass.AccessEndDate),
                                        _DbManager.Parameter("@Purpose", p_EventsClass.Purpose),
                                        _DbManager.Parameter("@WhomeToMeet", p_EventsClass.WhomeToMeet),
                                        _DbManager.Parameter("@Photo", p_EventsClass.Photo),
                                        _DbManager.Parameter("@Department", p_EventsClass.Department),
                                        _DbManager.Parameter("@ExtraDetails", p_EventsClass.ExtraDetails),
                                        _DbManager.Parameter("@CardAddress", p_EventsClass.CardAddress),
                                        _DbManager.Parameter("@ExtraDetails", p_EventsClass.ExtraDetails),
                                        _DbManager.Parameter("@ContactNo", p_EventsClass.ContactNo),
                                        _DbManager.Parameter("@IdProofType", p_EventsClass.IdProofType),
                                        _DbManager.Parameter("@IdProofNumber", p_EventsClass.IdProofNumber),
                                        _DbManager.Parameter("@CardUpdateDate", p_EventsClass.CardUpdateDate))
                        .ExecuteNonQuery();
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        #region Not Required
        //        public List<LiveEvent> GetEventsByEventID(int p_EventID)
        //        {
        //            using (DbManager _DbManager = new DbManager())
        //            {
        //                try
        //                {
        //                    List<LiveEvent> _ListOfEvents = _DbManager
        //                   .SetCommand(@"SELECT EventID, ModuleId, ModuleName, ModuleIP, ModulePort, Password, TimeOut, IsEnable, ModuleUpdateDate,
        //                                DeviceID, ModuleId, DeviceName, DeviceAddress, IsEnabled, DeviceUpdateDate, DeviceNo,
        //                                CardPrimaryID, CardID, CardNumber, UserName, AccessStartDate, AccessEndDate, Purpose, WhomeToMeet, Photo, Department, ExtraDetails, Address, ContactNo, IdProofType, IdProofNumber, CardUpdateDate 
        //                                FROM MasterDevice WHERE EventID = @EventID)",
        //                    _DbManager.Parameter("@EventID", p_EventID)).ExecuteList<LiveEvent>();

        //                    return _ListOfEvents;
        //                }
        //                finally
        //                {
        //                    _DbManager.Connection.Close();
        //                    _DbManager.Connection.Dispose();
        //                }
        //            }
        //        }

        //        public void UpdateDevice(LiveEvent p_EventsClass)
        //        {
        //            using (DbManager _DbManager = new DbManager())
        //            {
        //                try
        //                {
        //                    _DbManager.SetCommand(@"UPDATE Events
        //                                            SET ModuleId=@ModuleId, ModuleName=@ModuleName, ModuleIP=@ModuleIP, ModulePort=@ModulePort, ModulePassword=@ModulePassword, ModuleTimeOut=@ModuleTimeOut, ModuleIsEnabled=@ModuleIsEnabled, ModuleUpdateDate=@ModuleUpdateDate,
        //                                            DeviceID=@DeviceID, DeviceName=@DeviceName, DeviceAddress=@DeviceAddress, DeviceIsEnabled=@DeviceIsEnabled, DeviceUpdateDate=@DeviceUpdateDate, DeviceNo=@DeviceNo,
        //                                            CardPrimaryID=@CardPrimaryID, CardID=@CardID, CardNumber=@CardNumber, UserName=@UserName, AccessStartDate=@AccessStartDate, AccessEndDate=@AccessEndDate, Purpose=@Purpose, WhomeToMeet=@WhomeToMeet, Photo=@Photo, Department=@Department, ExtraDetails=@ExtraDetails, CardAddress=@CardAddress, ContactNo=@ContactNo, IdProofType=@IdProofType, IdProofNumber=@IdProofNumber, CardUpdateDate=@CardUpdateDate
        //                                            WHERE EventID=@EventID",
        //                                        _DbManager.Parameter("@ModuleId", p_EventsClass.ModuleId),
        //                                        _DbManager.Parameter("@ModuleName", p_EventsClass.ModuleName),
        //                                        _DbManager.Parameter("@ModuleIP", p_EventsClass.ModuleIP),
        //                                        _DbManager.Parameter("@ModulePort", p_EventsClass.ModulePort),
        //                                        _DbManager.Parameter("@ModulePassword", p_EventsClass.ModulePassword),
        //                                        _DbManager.Parameter("@ModuleTimeOut", p_EventsClass.ModuleTimeOut),
        //                                        _DbManager.Parameter("@ModuleIsEnabled", p_EventsClass.ModuleIsEnabled),
        //                                        _DbManager.Parameter("@ModuleUpdateDate", p_EventsClass.ModuleUpdateDate),

        //                                        _DbManager.Parameter("@DeviceId", p_EventsClass.DeviceId),
        //                                        _DbManager.Parameter("@DeviceName", p_EventsClass.DeviceName),
        //                                        _DbManager.Parameter("@DeviceAddress", p_EventsClass.DeviceAddress),
        //                                        _DbManager.Parameter("@DeviceIsEnabled", p_EventsClass.DeviceIsEnabled),
        //                                        _DbManager.Parameter("@DeviceUpdateDate", p_EventsClass.DeviceUpdateDate),
        //                                        _DbManager.Parameter("@DeviceNo", p_EventsClass.DeviceNo),

        //                                        _DbManager.Parameter("@CardPrimaryID", p_EventsClass.CardPrimaryID),
        //                                        _DbManager.Parameter("@CardID", p_EventsClass.CardID),
        //                                        _DbManager.Parameter("@CardNumber", p_EventsClass.CardNumber),
        //                                        _DbManager.Parameter("@UserName", p_EventsClass.UserName),
        //                                        _DbManager.Parameter("@AccessStartDate", p_EventsClass.AccessStartDate),
        //                                        _DbManager.Parameter("@AccessEndDate", p_EventsClass.AccessEndDate),
        //                                        _DbManager.Parameter("@Purpose", p_EventsClass.Purpose),
        //                                        _DbManager.Parameter("@WhomeToMeet", p_EventsClass.WhomeToMeet),
        //                                        _DbManager.Parameter("@Photo", p_EventsClass.Photo),
        //                                        _DbManager.Parameter("@Department", p_EventsClass.Department),
        //                                        _DbManager.Parameter("@ExtraDetails", p_EventsClass.ExtraDetails),
        //                                        _DbManager.Parameter("@CardAddress", p_EventsClass.CardAddress),
        //                                        _DbManager.Parameter("@ExtraDetails", p_EventsClass.ExtraDetails),
        //                                        _DbManager.Parameter("@ContactNo", p_EventsClass.ContactNo),
        //                                        _DbManager.Parameter("@IdProofType", p_EventsClass.IdProofType),
        //                                        _DbManager.Parameter("@IdProofNumber", p_EventsClass.IdProofNumber),
        //                                        _DbManager.Parameter("@CardUpdateDate", p_EventsClass.CardUpdateDate),
        //                                        _DbManager.Parameter("@EventID", p_EventsClass.EventID))
        //                     .ExecuteNonQuery();
        //                }
        //                finally
        //                {
        //                    _DbManager.Connection.Close();
        //                    _DbManager.Connection.Dispose();
        //                }
        //            }
        //        }

        //        public void DeleteDevice(LiveEvent p_EventsClass)
        //        {
        //            using (DbManager _DbManager = new DbManager())
        //            {
        //                try
        //                {
        //                    _DbManager.SetCommand(@"DELETE FROM Events WHERE EventID=@EventID",
        //                                _DbManager.Parameter("@EventID", p_EventsClass.EventID))
        //                             .ExecuteNonQuery();
        //                }
        //                finally
        //                {
        //                    _DbManager.Connection.Close();
        //                    _DbManager.Connection.Dispose();
        //                }
        //            }
        //        } 
        #endregion

        public List<LiveEvent> GetEvents(VMS.DataAccess.Helpers.Enums.ReportTypes p_ReportTypes, DateTime? p_FromDate = null, DateTime? p_ToDate = null,
            string p_CardID = "", string p_DeviceName = "", string p_ContactNo = "", string p_WhomeToMeet = "")
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<LiveEvent> _ListOfEvents = new List<LiveEvent>();

                    if (p_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.Date)
                    {
                        _ListOfEvents = _DbManager
                                        .SetCommand(@"SELECT ModuleName, DeviceName, CardID FROM Events
                                        WHERE CAST(EventDateTime AS DATE) BETWEEN CAST(@FromDate AS DATE) AND CAST(@ToDate AS DATE)",
                                        _DbManager.Parameter("@FromDate", p_FromDate),
                                        _DbManager.Parameter("@ToDate", p_ToDate)).ExecuteList<LiveEvent>();
                    }

                    if (p_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.Card)
                    {
                        _ListOfEvents = _DbManager
                                        .SetCommand(@"SELECT ModuleName, DeviceName, CardID FROM Events
                                        WHERE CardID = @CardID",
                                        _DbManager.Parameter("@CardID", p_CardID)).ExecuteList<LiveEvent>();
                    }

                    if (p_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.Device)
                    {
                        _ListOfEvents = _DbManager
                                        .SetCommand(@"SELECT ModuleName, DeviceName, CardID FROM Events
                                        WHERE CardID = @DeviceName",
                                        _DbManager.Parameter("@DeviceName", p_DeviceName)).ExecuteList<LiveEvent>();
                    }

                    if (p_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.VisitorContactNo)
                    {
                        _ListOfEvents = _DbManager
                                        .SetCommand(@"SELECT ModuleName, DeviceName, CardID FROM Events
                                        WHERE CardID = @ContactNo",
                                        _DbManager.Parameter("@ContactNo", p_ContactNo)).ExecuteList<LiveEvent>();
                    }

                    if (p_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.VisitorName)
                    {
                        _ListOfEvents = _DbManager
                                        .SetCommand(@"SELECT ModuleName, DeviceName, CardID FROM Events
                                        WHERE CardID = @WhomeToMeet",
                                        _DbManager.Parameter("@WhomeToMeet", p_WhomeToMeet)).ExecuteList<LiveEvent>();
                    }

                    return _ListOfEvents;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }
        #endregion
    }
}
