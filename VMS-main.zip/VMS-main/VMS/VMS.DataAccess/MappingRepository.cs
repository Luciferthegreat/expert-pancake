﻿using BLToolkit.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.DataModels.CommonModels;
using VMS.DataModels.Models;

namespace VMS.DataAccess
{
    public class MappingRepository
    {
        #region Properites
        #endregion

        #region Ctor
        #endregion

        #region Methods
        public List<MappingClass> GetAllMapping()
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<MappingClass> _ListOfCardDeviceMappingDetailClass = _DbManager
                   .SetCommand(@"SELECT CDM.CardDeviceMappingID, MM.ModuleId, MM.ModuleName, MM.ModuleIP, MM.ModulePort, MM.Password, MM.TimeOut, MM.IsEnable, MM.ModuleUpdateDate,
                                MD.DeviceID, MD.ModuleId, MD.DeviceName, MD.DeviceAddress, MD.IsEnabled, MD.DeviceUpdateDate,
                                MC.CardPrimaryID, MC.CardID, MC.CardNumber, MC.UserName, MC.AccessStartDate, MC.AccessEndDate, MC.Purpose, MC.WhomeToMeet, MC.Photo, MC.Department, MC.ExtraDetails, MC.Address, MC.ContactNo, MC.IdProofType, MC.IdProofNumber, MC.CardUpdateDate 
                                FROM CardDeviceMapping CDM JOIN MasterCard MC ON CDM.CardPrimaryID = MC.CardPrimaryID
                                JOIN MasterDevice MD ON CDM.DeviceID = MD.DeviceID
                                JOIN MasterModule MM ON CDM.ModuleId = MM.ModuleId").ExecuteList<MappingClass>();

                    return _ListOfCardDeviceMappingDetailClass;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public List<MappingClass> GetMappingByID(int p_CardDeviceMappingID)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<MappingClass> _ListOfCardDeviceMappingDetailClass = _DbManager
                   .SetCommand(@"SELECT CDM.CardDeviceMappingID, MM.ModuleId, MM.ModuleName, MM.ModuleIP, MM.ModulePort, MM.Password, MM.TimeOut, MM.IsEnable, MM.ModuleUpdateDate,
                                MD.DeviceID, MD.ModuleId, MD.DeviceName, MD.DeviceAddress, MD.IsEnabled, MD.DeviceUpdateDate,
                                MC.CardPrimaryID, MC.CardID, MC.CardNumber, MC.UserName, MC.AccessStartDate, MC.AccessEndDate, MC.Purpose, MC.WhomeToMeet, MC.Photo, MC.Department, MC.ExtraDetails, MC.Address, MC.ContactNo, MC.IdProofType, MC.IdProofNumber, MC.CardUpdateDate 
                                FROM CardDeviceMapping CDM JOIN MasterCard MC ON CDM.CardPrimaryID = MC.CardPrimaryID
                                JOIN MasterDevice MD ON CDM.DeviceID = MD.DeviceID
                                JOIN MasterModule MM ON CDM.ModuleId = MM.ModuleId
                                WHERE CDM.CardDeviceMappingID = @CardDeviceMappingID)",
                    _DbManager.Parameter("@CardDeviceMappingID", p_CardDeviceMappingID)).ExecuteList<MappingClass>();

                    return _ListOfCardDeviceMappingDetailClass;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void InsertMapping(MappingClass p_CardDeviceMapping)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {

                    _DbManager.SetCommand(@"INSERT INTO CardDeviceMapping (CardPrimaryID, DeviceID, ModuleId)
                                    VALUES (@CardPrimaryID, @DeviceID, @ModuleId)",
                                        _DbManager.Parameter("@CardPrimaryID", p_CardDeviceMapping.CardPrimaryID),
                                        _DbManager.Parameter("@DeviceID", p_CardDeviceMapping.DeviceID),
                                        _DbManager.Parameter("@ModuleId", p_CardDeviceMapping.ModuleId))
                        .ExecuteNonQuery();
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void UpdateMapping(MappingClass p_CardDeviceMapping)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    _DbManager.SetCommand(@"UPDATE CardDeviceMapping
                                          SET CardPrimaryID=@CardPrimaryID, DeviceID=@DeviceID, ModuleId=@ModuleId
                                          WHERE CardDeviceMappingID=@CardDeviceMappingID",
                                          _DbManager.Parameter("@CardPrimaryID", p_CardDeviceMapping.CardPrimaryID),
                                          _DbManager.Parameter("@DeviceID", p_CardDeviceMapping.DeviceID),
                                          _DbManager.Parameter("@ModuleId", p_CardDeviceMapping.ModuleId),
                                          _DbManager.Parameter("@CardDeviceMappingID", p_CardDeviceMapping.CardDeviceMappingID))
                     .ExecuteNonQuery();
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void DeleteMapping(MappingClass p_CardDeviceMapping)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    _DbManager.SetCommand(@"DELETE FROM CardDeviceMapping WHERE CardDeviceMappingID=@CardDeviceMappingID",
                                _DbManager.Parameter("@CardDeviceMappingID", p_CardDeviceMapping.CardDeviceMappingID))
                             .ExecuteNonQuery();
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void InsertOrUpdateMapping(MappingClass p_MappingClass)
        {
            if (p_MappingClass.CardDeviceMappingID != 0)
            {
                UpdateMapping(p_MappingClass);
            }
            else
            {
                InsertMapping(p_MappingClass);
            }
        }
        #endregion
    }
}
