﻿using BLToolkit.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.DataModels.Models;

namespace VMS.DataAccess
{
    public class DeviceRepository
    {
        #region Properites
        #endregion

        #region Ctor
        #endregion

        #region Methods
        public List<DeviceMaster> GetAllDevice()
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<DeviceMaster> _ListOfDeviceMaster = _DbManager
                   .SetCommand(@"SELECT DeviceID, MD.ModuleId, MM.ModuleName, DeviceName, DeviceAddress, MD.IsEnabled, DeviceUpdateDate, DeviceNo
                                FROM MasterDevice MD
                                JOIN MasterModule MM ON MD.ModuleId = MM.ModuleId").ExecuteList<DeviceMaster>();

                    return _ListOfDeviceMaster;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public List<DeviceMaster> GetDeviceByDeviceID(long p_DeviceID)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<DeviceMaster> _ListOfDeviceMaster = _DbManager
                   .SetCommand(@"SELECT DeviceID, MD.ModuleId, MM.ModuleName, DeviceName, DeviceAddress, MD.IsEnabled, DeviceUpdateDate, MD.DeviceNo
                                FROM MasterDevice MD
                                JOIN MasterModule MM ON MD.ModuleId = MM.ModuleId WHERE DeviceID = @DeviceID",
                    _DbManager.Parameter("@DeviceID", p_DeviceID)).ExecuteList<DeviceMaster>();

                    return _ListOfDeviceMaster;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }


        public List<DeviceMaster> GetDeviceByModuleIDAndDeviceNo(long p_ModuleNo, int p_DeviceNo)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<DeviceMaster> _ListOfDeviceMaster = _DbManager
                   .SetCommand(@"SELECT DeviceID, MD.ModuleId, MM.ModuleName, DeviceName, DeviceAddress, MD.IsEnabled, DeviceUpdateDate, MD.DeviceNo
                                FROM MasterDevice MD
                                JOIN MasterModule MM ON MD.ModuleId = MM.ModuleId WHERE DeviceNo = @DeviceNo  and MD.ModuleId = @ModuleId",
                    _DbManager.Parameter("@DeviceNo", p_DeviceNo),
                    _DbManager.Parameter("@ModuleId", p_ModuleNo)).ExecuteList<DeviceMaster>();

                    return _ListOfDeviceMaster;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public List<DeviceMaster> GetDeviceByName(DeviceMaster p_DeviceMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<DeviceMaster> _ListOfDeviceMaster;
                    if (p_DeviceMaster.DeviceID == 0)
                    {
                        _ListOfDeviceMaster = _DbManager
                       .SetCommand(@"SELECT DeviceID, DeviceName, DeviceAddress, IsEnabled, DeviceUpdateDate, DeviceNo
                                    FROM MasterDevice WHERE DeviceName = @DeviceName",
                                    _DbManager.Parameter("@DeviceName", p_DeviceMaster.DeviceName.Trim())).ExecuteList<DeviceMaster>();
                    }
                    else
                    {
                        _ListOfDeviceMaster = _DbManager
                       .SetCommand(@"SELECT DeviceID, DeviceName, DeviceAddress, IsEnabled, DeviceUpdateDate, DeviceNo
                                    FROM MasterDevice WHERE DeviceName = @DeviceName AND DeviceID != @DeviceID",
                                    _DbManager.Parameter("@DeviceName", p_DeviceMaster.DeviceName.Trim()),
                                    _DbManager.Parameter("@DeviceID", p_DeviceMaster.DeviceID)).ExecuteList<DeviceMaster>();
                    }
                    return _ListOfDeviceMaster;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public bool InsertDevice(DeviceMaster p_DeviceMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {

                    int retValue = _DbManager.SetCommand(@"INSERT INTO MasterDevice (ModuleId, DeviceName, DeviceAddress, IsEnabled, DeviceUpdateDate, DeviceNo)
                                    VALUES (@ModuleId, @DeviceName, @DeviceAddress, @IsEnabled, @DeviceUpdateDate, @DeviceNo)",
                                         _DbManager.Parameter("@ModuleId", p_DeviceMaster.ModuleId),
                                         _DbManager.Parameter("@DeviceName", p_DeviceMaster.DeviceName),
                                         _DbManager.Parameter("@DeviceAddress", p_DeviceMaster.DeviceAddress),
                                         _DbManager.Parameter("@IsEnabled", p_DeviceMaster.IsEnabled),
                                         _DbManager.Parameter("@DeviceUpdateDate", p_DeviceMaster.DeviceUpdateDate),
                                         _DbManager.Parameter("@DeviceNo", p_DeviceMaster.DeviceNo))
                         .ExecuteNonQuery();

                    return (retValue > 0);
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void UpdateDevice(DeviceMaster p_DeviceMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    _DbManager.SetCommand(@"UPDATE MasterDevice
                                          SET ModuleId=@ModuleId, DeviceName=@DeviceName, DeviceAddress=@DeviceAddress,
                                          IsEnabled=@IsEnabled, DeviceUpdateDate=@DeviceUpdateDate DeviceNo=@DeviceNo
                                          WHERE DeviceID=@DeviceID",
                                          _DbManager.Parameter("@ModuleId", p_DeviceMaster.ModuleId),
                                          _DbManager.Parameter("@DeviceName", p_DeviceMaster.DeviceName),
                                          _DbManager.Parameter("@DeviceAddress", p_DeviceMaster.DeviceAddress),
                                          _DbManager.Parameter("@IsEnabled", p_DeviceMaster.IsEnabled),
                                          _DbManager.Parameter("@DeviceUpdateDate", p_DeviceMaster.DeviceUpdateDate),
                                          _DbManager.Parameter("@DeviceNo", p_DeviceMaster.DeviceNo),
                                          _DbManager.Parameter("@DeviceID", p_DeviceMaster.DeviceID))
                     .ExecuteNonQuery();
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void DeleteDevice(DeviceMaster p_DeviceMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    _DbManager.SetCommand(@"DELETE FROM MasterDevice WHERE DeviceID=@DeviceID",
                                _DbManager.Parameter("@DeviceID", p_DeviceMaster.DeviceID))
                             .ExecuteNonQuery();
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void InsertOrUpdateDevice(DeviceMaster p_DeviceMaster)
        {
            if(p_DeviceMaster.DeviceID != 0)
            {
                UpdateDevice(p_DeviceMaster);
            }
            else
            {
                InsertDevice(p_DeviceMaster);
            }
        }
        #endregion
    }
}
