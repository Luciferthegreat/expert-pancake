﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.DataAccess
{
    public partial class DbManager : BLToolkit.Data.DbManager
    {
        public DbManager()
            : base(new BLToolkit.Data.DataProvider.SqlDataProvider(), @"Data Source=DESKTOP-STL25JJ\GURU;Initial Catalog=VMS;Integrated Security=True")
        {
            //System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString

            //string conString = VMS.DataAccess.Properties.Settings.Default.ConnectionString;
            //this.ConfigurationString = conString;
        }
    }
}
