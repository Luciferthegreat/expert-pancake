﻿using BLToolkit.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VMS.DataModels.Models;

namespace VMS.DataAccess
{
    public class CardRepository
    {
        #region Properites
        #endregion

        #region Ctor
        #endregion

        #region Methods
        public List<CardMaster> GetAllCard()
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<CardMaster> _ListOfCardMaster = _DbManager
                   .SetCommand(@"SELECT CardPrimaryID, CardID, CardNumber, UserName, AccessStartDate, AccessEndDate, Purpose,
                            WhomeToMeet, Photo, Department, ExtraDetails, Address, ContactNo, IdProofType, IdProofNumber, CardUpdateDate
                            FROM MasterCard").ExecuteList<CardMaster>();

                    return _ListOfCardMaster;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public List<CardMaster> GetCardByCardPrimaryID(long p_CardPrimaryID)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<CardMaster> _ListOfCardMaster = _DbManager
                   .SetCommand(@"SELECT CardPrimaryID, CardID, CardNumber, UserName, AccessStartDate, AccessEndDate, Purpose,
                            WhomeToMeet, Photo, Department, ExtraDetails, Address, ContactNo, IdProofType, IdProofNumber, CardUpdateDate
                            FROM MasterCard WHERE CardPrimaryID = @CardPrimaryID",
                    _DbManager.Parameter("@CardPrimaryID", p_CardPrimaryID)).ExecuteList<CardMaster>();

                    return _ListOfCardMaster;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public List<CardMaster> GetCardByIdAndNumber(CardMaster p_CardMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    List<CardMaster> _ListOfCardMaster;
                    if (p_CardMaster.CardPrimaryID == 0)
                    {
                        _ListOfCardMaster = _DbManager
                       .SetCommand(@"SELECT CardPrimaryID, CardID, CardNumber, UserName, AccessStartDate, AccessEndDate, Purpose,
                                    WhomeToMeet, Photo, Department, ExtraDetails, Address, ContactNo, IdProofType, IdProofNumber, CardUpdateDate
                                    FROM MasterCard WHERE CardID = @CardID AND CardNumber = @CardNumber",
                                    _DbManager.Parameter("@CardID", p_CardMaster.CardID.Trim()),
                                    _DbManager.Parameter("@CardNumber", p_CardMaster.CardNumber.Trim())).ExecuteList<CardMaster>();
                    }
                    else
                    {
                        _ListOfCardMaster = _DbManager
                       .SetCommand(@"SELECT CardPrimaryID, CardID, CardNumber, UserName, AccessStartDate, AccessEndDate, Purpose,
                                    WhomeToMeet, Photo, Department, ExtraDetails, Address, ContactNo, IdProofType, IdProofNumber, CardUpdateDate
                                    FROM MasterCard WHERE CardID = @CardID AND CardNumber = @CardNumber AND CardPrimaryID != @CardPrimaryID",
                                    _DbManager.Parameter("@CardID", p_CardMaster.CardID.Trim()),
                                    _DbManager.Parameter("@CardNumber", p_CardMaster.CardNumber.Trim()),
                                    _DbManager.Parameter("@CardPrimaryID", p_CardMaster.CardPrimaryID)).ExecuteList<CardMaster>();
                    }
                    return _ListOfCardMaster;
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void InsertCard(CardMaster p_CardMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {

                    _DbManager.SetCommand(@"INSERT INTO MasterCard (CardID, CardNumber, UserName, AccessStartDate, AccessEndDate, Purpose,
                                    WhomeToMeet, Photo, Department, ExtraDetails, Address, ContactNo, IdProofType, IdProofNumber, CardUpdateDate)
                                    VALUES (@CardID, @CardNumber, @UserName, @AccessStartDate, @AccessEndDate, @Purpose,
                                    @WhomeToMeet, @Photo, @Department, @ExtraDetails, @Address, @ContactNo, @IdProofType, @IdProofNumber, @CardUpdateDate)",
                                        _DbManager.Parameter("@CardID", p_CardMaster.CardID),
                                        _DbManager.Parameter("@CardNumber", p_CardMaster.CardNumber),
                                        _DbManager.Parameter("@UserName", p_CardMaster.UserName),
                                        _DbManager.Parameter("@AccessStartDate", p_CardMaster.AccessStartDate),
                                        _DbManager.Parameter("@AccessEndDate", p_CardMaster.AccessEndDate),
                                        _DbManager.Parameter("@Purpose", p_CardMaster.Purpose),
                                        _DbManager.Parameter("@WhomeToMeet", p_CardMaster.WhomeToMeet),
                                        _DbManager.Parameter("@Photo", p_CardMaster.Photo),
                                        _DbManager.Parameter("@Department", p_CardMaster.Department),
                                        _DbManager.Parameter("@ExtraDetails", p_CardMaster.ExtraDetails),
                                        _DbManager.Parameter("@Address", p_CardMaster.Address),
                                        _DbManager.Parameter("@ContactNo", p_CardMaster.ContactNo),
                                        _DbManager.Parameter("@IdProofType", p_CardMaster.IdProofType),
                                        _DbManager.Parameter("@IdProofNumber", p_CardMaster.IdProofNumber),
                                        _DbManager.Parameter("@CardUpdateDate", p_CardMaster.CardUpdateDate))
                        .ExecuteNonQuery();
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void UpdateCard(CardMaster p_CardMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    _DbManager.SetCommand(@"UPDATE MasterCard
                             SET CardID=@CardID, CardNumber=@CardNumber, UserName=@UserName, AccessStartDate=@AccessStartDate, 
                             AccessEndDate=@AccessEndDate, Purpose=@Purpose, WhomeToMeet=@WhomeToMeet, Photo=@Photo, 
                             Department=@Department, ExtraDetails=@ExtraDetails, Address=@Address, ContactNo=@ContactNo, 
                             IdProofType=@IdProofType, IdProofNumber=@IdProofNumber,
                             CardUpdateDate=@CardUpdateDate
                             WHERE CardPrimaryID=@CardPrimaryID",
                            _DbManager.Parameter("@CardID", p_CardMaster.CardID),
                            _DbManager.Parameter("@CardNumber", p_CardMaster.CardNumber),
                            _DbManager.Parameter("@UserName", p_CardMaster.UserName),
                            _DbManager.Parameter("@AccessStartDate", p_CardMaster.AccessStartDate),
                            _DbManager.Parameter("@AccessEndDate", p_CardMaster.AccessEndDate),
                            _DbManager.Parameter("@Purpose", p_CardMaster.Purpose),
                            _DbManager.Parameter("@WhomeToMeet", p_CardMaster.WhomeToMeet),
                            _DbManager.Parameter("@Photo", p_CardMaster.Photo),
                            _DbManager.Parameter("@Department", p_CardMaster.Department),
                            _DbManager.Parameter("@ExtraDetails", p_CardMaster.ExtraDetails),
                            _DbManager.Parameter("@Address", p_CardMaster.Address),
                            _DbManager.Parameter("@ContactNo", p_CardMaster.ContactNo),
                            _DbManager.Parameter("@IdProofType", p_CardMaster.IdProofType),
                            _DbManager.Parameter("@IdProofNumber", p_CardMaster.IdProofNumber),
                            _DbManager.Parameter("@CardUpdateDate", p_CardMaster.CardUpdateDate),
                            _DbManager.Parameter("@CardPrimaryID", p_CardMaster.CardPrimaryID))
                     .ExecuteNonQuery();
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void DeleteCard(CardMaster p_CardMaster)
        {
            using (DbManager _DbManager = new DbManager())
            {
                try
                {
                    _DbManager.SetCommand(@"DELETE FROM MasterCard WHERE CardPrimaryID=@CardPrimaryID",
                                _DbManager.Parameter("@CardPrimaryID", p_CardMaster.CardPrimaryID))
                             .ExecuteNonQuery();
                }
                finally
                {
                    _DbManager.Connection.Close();
                    _DbManager.Connection.Dispose();
                }
            }
        }

        public void InsertOrUpdateCard(CardMaster p_CardMaster)
        {
            if (p_CardMaster.CardPrimaryID != 0)
            {
                UpdateCard(p_CardMaster);
            }
            else
            {
                InsertCard(p_CardMaster);
            }
        }
        #endregion
    }
}
