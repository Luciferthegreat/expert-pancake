CREATE TABLE [dbo].[MasterCard] (
    [CardPrimaryID]   INT IDENTITY(1,1) NOT NULL,
    [CardID]          VARCHAR (100) NULL,
    [CardName]        VARCHAR (100) NOT NULL,
    [UserName]        VARCHAR (100) NULL,
    [AccessStartDate] DATETIME      NULL,
    [AccessEndDate]   DATETIME      NULL,
    [Purpose]         TEXT          NOT NULL,
    [WhomeToMeet]     VARCHAR (100) NOT NULL,
    [Photo]           TEXT          NULL,
    [Department]      VARCHAR (100) NULL,
    [ExtraDetails]    TEXT          NULL,
    [Address]         TEXT          NULL,
    [ContactNo]       VARCHAR (50)  NOT NULL,
    [CardUpdateDate]  DATETIME      NOT NULL,
    PRIMARY KEY CLUSTERED ([CardPrimaryID] ASC)
);


GO

CREATE TABLE [dbo].[MasterDevice] (
    [DeviceID]         INT IDENTITY(1,1) NOT NULL,
    [DeviceName]       VARCHAR (100) NOT NULL,
    [DeviceIP]         VARCHAR (100) NOT NULL,
    [DevicePort]       VARCHAR (100) NOT NULL,
    [IsEnabled]        BIT           NULL,
    [DeviceUpdateDate] DATETIME      NOT NULL,
    PRIMARY KEY CLUSTERED ([DeviceID] ASC)
);


GO

CREATE TABLE [dbo].[CardDeviceMapping] (
    [CardDeviceMappingID] INT IDENTITY(1,1) NOT NULL,
    [CardPrimaryID]       INT NOT NULL,
    [DeviceID]            INT NOT NULL,
    PRIMARY KEY CLUSTERED ([CardDeviceMappingID] ASC)
);


GO

CREATE TABLE [dbo].[Events] (
    [EventID]         INT IDENTITY(1,1) NOT NULL,
    [EventDateTime]   DATETIME      NULL,
    [EventType]       VARCHAR (50)  NULL,
    [SourceType]      VARCHAR (50)  NULL,
    [CardName]        VARCHAR (100) NULL,
    [UserName]        VARCHAR (100) NULL,
    [AccessStartDate] DATETIME      NULL,
    [AccessEndDate]   DATETIME      NULL,
    [Purpose]         TEXT          NULL,
    [WhomeToMeet]     VARCHAR (100) NULL,
    [Photo]           TEXT          NULL,
    [Department]      VARCHAR (100) NULL,
    [ExtraDetails]    TEXT          NULL,
    [Address]         TEXT          NULL,
    [ContactNo]       VARCHAR (50)  NULL,
    [DeviceName]      VARCHAR (100) NULL,
    [DeviceIP]        VARCHAR (100) NULL,
    [DevicePort]      VARCHAR (100) NULL,
    PRIMARY KEY CLUSTERED ([EventID] ASC)
);


GO