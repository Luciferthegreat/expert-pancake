
CREATE TABLE [dbo].[MasterModule](
	[ModuleId] [int] IDENTITY(1,1) NOT NULL,
	[ModuleName] [varchar](100) NULL,
	[ModuleIP] [varchar](100) NULL,
	[ModulePort] [varchar](100) NULL,
	[Password] [nchar](10) NULL,
	[TimeOut ] [int] NULL,
	[IsEnable] [bit] NULL,
	[ModuleUpdateDate] [datetime] NULL
) ON [PRIMARY]

GO


CREATE TABLE [dbo].[MasterDevice](
	[DeviceID] [int] IDENTITY(1,1) NOT NULL,
	[ModuleId] [int] NOT NULL,
	[DeviceName] [varchar](100) NOT NULL,
	[DeviceAddress] [varchar](100) NOT NULL,
	[IsEnabled] [bit] NULL,
	[DeviceUpdateDate] [datetime] NULL,
 CONSTRAINT [PK_MasterDevice] PRIMARY KEY CLUSTERED 
(
	[DeviceID] ASC,
	[ModuleId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


CREATE TABLE [dbo].[MasterCard](
	[CardPrimaryID] [int] IDENTITY(1,1) NOT NULL,
	[CardID] [varchar](100) NOT NULL,
	[CardNumber] [varchar](100) NOT NULL,
	[UserName] [varchar](100) NULL,
	[AccessStartDate] [datetime] NULL,
	[AccessEndDate] [datetime] NULL,
	[Purpose] [text] NOT NULL,
	[WhomeToMeet] [varchar](100) NOT NULL,
	[Photo] [text] NULL,
	[Department] [varchar](100) NULL,
	[ExtraDetails] [text] NULL,
	[Address] [text] NULL,
	[ContactNo] [varchar](50) NOT NULL,
	[IdProofType] [varchar](100) NULL,
	[IdProofNumber] [varchar](100) NULL,
	[CardUpdateDate] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


CREATE TABLE [dbo].[CardDeviceMapping](
	[CardDeviceMappingID] [int] IDENTITY(1,1) NOT NULL,
	[CardPrimaryID] [int] NOT NULL,
	[DeviceID] [int] NOT NULL,
	[ModuleId] [int] NOT NULL
) ON [PRIMARY]

GO


CREATE TABLE [dbo].[Events](
	[EventID] [int] IDENTITY(1,1) NOT NULL,
	[ModuleId] [int] NULL,
	[ModuleName] [varchar](100) NULL,
	[ModuleIP] [varchar](100) NULL,
	[ModulePort] [varchar](100) NULL,
	[ModulePassword] [nchar](10) NULL,
	[ModuleTimeOut ] [int] NULL,
	[ModuleIsEnabled] [bit] NULL,
	[ModuleModuleUpdateDate] [datetime] NULL,
	[DeviceId] [int] NULL,
	[DeviceName] [varchar](100) NULL,
	[DeviceAddress] [varchar](100) NULL,
	[DeviceIsEnabled] [bit] NULL,
	[DeviceUpdateDate] [datetime] NULL,
	[CardPrimaryID] [int] NULL,
	[CardID] [varchar](100) NULL,
	[CardNumber] [varchar](100) NULL,
	[UserName] [varchar](100) NULL,
	[AccessStartDate] [datetime] NULL,
	[AccessEndDate] [datetime] NULL,
	[Purpose] [text] NULL,
	[WhomeToMeet] [varchar](100) NULL,
	[Photo] [text] NULL,
	[Department] [varchar](100) NULL,
	[ExtraDetails] [text] NULL,
	[CardAddress] [text] NULL,
	[ContactNo] [varchar](50) NULL,
	[IdProofType] [varchar](100) NULL,
	[IdProofNumber] [varchar](100) NULL,
	[CardUpdateDate] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[Events] ADD
	[EventType] [int] NULL,
	[EventDateTime] [datetime] NULL
GO

CREATE PROCEDURE GetReportData
	@FromDate Datetime,
    @ToDate Datetime,
    @CardID varchar(100) = null,
    @DeviceName varchar(100) = null
    
    AS
    BEGIN
		SELECT EventID, ModuleId, ModuleName, ModuleIP, ModulePort, ModulePassword, ModuleTimeOut, ModuleIsEnabled,
		ModuleModuleUpdateDate, DeviceId, DeviceName, DeviceAddress, DeviceIsEnabled, DeviceUpdateDate, CardPrimaryID,
		CardID, CardNumber, UserName, AccessStartDate, AccessEndDate, Purpose, WhomeToMeet, Photo, Department, ExtraDetails,
		CardAddress, ContactNo, IdProofType, IdProofNumber ,CardUpdateDate, EventType, EventDateTime
		FROM events
		WHERE CAST(EventDateTime AS DATE) BETWEEN CAST(@FromDate AS DATE) AND CAST(@ToDate AS DATE)
		AND (@CardID IS NULL OR (CardID = @CardID))
		AND (@DeviceName IS NULL OR (DeviceName = @DeviceName))
		
	END

GO


ALTER TABLE dbo.MasterDevice ADD
	DeviceNo tinyint NULL
GO

ALTER TABLE dbo.Events ADD
	DeviceNo tinyint NULL
GO



