﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.DeviceAccess
{
    public class EventHandlers
    {
        public delegate void ErrorOccuredEventHandler(Exception errorMessage);

        public delegate void DeviceConnectionCompletedEventHandler(DeviceConnectionStatus status);

        public delegate void EventReceivedEventHandler(DeviceEvent devEvent);

    }
}
