﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.DeviceAccess
{
    internal class Constants
    {
        public const string PROTOCOL_TCP = "TCP";
        public const string PROTOCOL_RS485 = "RS485";


        //protocol=TCP,ipaddress=192.168.8.122,port=4370,timeout=2000,passwd=
        public const string CONNECTION_STRING = "protocol={0},ipaddress={1},port={2},timeout={3},passwd={4}";
    }
}
