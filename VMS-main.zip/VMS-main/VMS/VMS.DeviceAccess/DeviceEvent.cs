﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.DeviceAccess
{
    public class DeviceEvent
    {
        #region Properties
        public DateTime DateTime { get; set; }

        public string CardNo { get; set; }

        public int EventType { get; set; }

        public int DoorNo { get; set; }

        public int InOutState { get; set; }

        public int VerifyMode { get; set; }

        //This will be set when the event is received in DB Model Class
        public long ModuleDBID { get; set; }

        public long ReaderDBID { get; set; }
        #endregion
    }
}
