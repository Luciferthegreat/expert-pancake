﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace VMS.DeviceAccess
{
    public class BridgeDevice
    {

        #region Properties
        private ConnectionType connectionType;
        private string connectionTimeOut = "2000";
        IntPtr devicePntr = IntPtr.Zero;

        public event EventHandlers.ErrorOccuredEventHandler OnErrorOccured;
        public event EventHandlers.DeviceConnectionCompletedEventHandler OnConnectionCompleted;
        public event EventHandlers.EventReceivedEventHandler OnEventReceived;

        public bool IsDeviceConnected
        {
            get
            {
                return (devicePntr != IntPtr.Zero);
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Connects to the central device
        /// </summary>
        /// <param name="IPAddress"></param>
        /// <param name="port"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public bool ConnectDevice(string IPAddress, string port, string password)
        {
            try
            {
                string connectionString = String.Format(Constants.CONNECTION_STRING, Constants.PROTOCOL_TCP, IPAddress, port, connectionTimeOut, password.Trim());
                devicePntr = DeviceAdapter.Connect(connectionString);
                return IsDeviceConnected;
            }
            catch (Exception ex)
            {
                devicePntr = IntPtr.Zero;
                //RaiseOnErrorOccured(ex.Message);
                throw ex;
            }
            //return IsDeviceConnected;
        }

        /// <summary>
        /// Disconnects the device if connected.
        /// </summary>
        public void DisconnectDevice()
        {
            if (!IsDeviceConnected)
                return;

            DeviceAdapter.Disconnect(devicePntr);
            devicePntr = IntPtr.Zero;

        }


        public void TryGetEvent()
        {
            try
            {
                //Using threadpool to queue work items
                ThreadPool.QueueUserWorkItem(delegate(object state)
                 {
                     try
                     {
                         int ret = 0, i = 0, buffersize = 256;
                         string str = "";
                         string[] tmp = null;
                         byte[] buffer = new byte[256];
                         if (IntPtr.Zero != devicePntr)
                         {
                             ret = DeviceAdapter.GetRTLog(devicePntr, ref buffer[0], buffersize);
                             if (ret >= 0)
                             {
                                 str = Encoding.Default.GetString(buffer);
                                 tmp = str.Split(',');

                                 DeviceEvent evt = new DeviceEvent();
                                 evt.CardNo = tmp[2];

                                 //2016-09-27 23:15:59 . Date time format
                                 DateTime evtDateTime = DateTime.MinValue;
                                 bool dateParsed = DateTime.TryParse(tmp[0], out evtDateTime);
                                 if (!dateParsed)
                                     evt.DateTime = DateTime.Now;
                                 else
                                     evt.DateTime = evtDateTime;

                                 evt.EventType = Convert.ToInt32(tmp[4]);
                                 evt.InOutState = Convert.ToInt32(tmp[5]);
                                 evt.VerifyMode = Convert.ToInt32(tmp[6]);
                                 RaiseOnEventReceived(evt);

                             }
                         }
                     }
                     catch (Exception ex)
                     {
                         RaiseOnErrorOccured(ex);
                     }
                 }, null);
            }
            catch (Exception ex)
            {
                RaiseOnErrorOccured(ex);
            }
            finally
            {

            }
        }

        public void TryGetEventDataFromTransactionTable()
        {
            try
            {
                ThreadPool.QueueUserWorkItem(delegate(object state)
               {
                   try
                   {
                       int ret = 0;
                       string str = "";
                       int BUFFERSIZE = 1 * 1024 * 1024;
                       byte[] buffer = new byte[BUFFERSIZE];
                       string options = "";
                       bool opt = true;
                       string devtablename = "transaction";
                       string devDatFilter = "CardNo\tDoorID\tEventType\tInOutState\tStartTime\tEndTime";

                       if (str == "")
                           return;

                       if (opt)
                           options = "NewRecord";

                       if (IsDeviceConnected)
                       {
                           ret = DeviceAdapter.GetDeviceData(devicePntr, ref buffer[0], BUFFERSIZE, devtablename, str, devDatFilter, options);
                           if (ret >= 0)
                           {
                               string dataReturned = Encoding.Default.GetString(buffer);

                               string[] splittedData = dataReturned.Split(',');
                               if (splittedData != null)
                               {
                                   DeviceEvent devEvent = new DeviceEvent();
                                   devEvent.CardNo = splittedData[0];
                                   devEvent.DoorNo = Convert.ToInt32(splittedData[1]);
                                   devEvent.EventType = Convert.ToInt32(splittedData[2]);
                                   devEvent.InOutState = Convert.ToInt32(splittedData[3]);
                                   devEvent.DateTime = DateTime.Parse(splittedData[4]);
                               }
                           }
                       }
                   }
                   catch (Exception ex)
                   {
                       RaiseOnErrorOccured(ex);
                   }
               }, null);
            }
            catch (Exception ex)
            {
                RaiseOnErrorOccured(ex);
            }
        }

        #endregion

        #region Private Methods
        void RaiseOnErrorOccured(Exception message)
        {
            if (OnErrorOccured != null)
                OnErrorOccured(message);
        }

        void RaiseOnEventReceived(DeviceEvent devEvent)
        {
            if (OnEventReceived != null)
                OnEventReceived(devEvent);
        }
        #endregion
    }
}
