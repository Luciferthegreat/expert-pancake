﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace VMS.Helpers
{
    public class RelayCommand : ICommand
    {
        #region Fields

        readonly Action<object> _execute;
        readonly Predicate<object> _canExecute;

        #endregion // Fields

        #region Constructors

        public RelayCommand(Action<object> execute)
            : this(execute, null)
        {
        }

        public RelayCommand(Action<object> execute, Predicate<object> canExecute)
        {
            if (execute == null)
                throw new ArgumentNullException("execute");

            _execute = execute;
            _canExecute = canExecute;
        }

        #endregion // Constructors

        #region ICommand Members

        [DebuggerStepThrough]
        public bool CanExecute(object parameter)
        {
            return _canExecute == null ? true : _canExecute(parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public void Execute(object parameter)
        {
            System.Windows.Input.Mouse.OverrideCursor = Cursors.Wait;
            try
            {
                IsBusy = true;
                _execute(parameter);
            }
            finally
            {
                System.Windows.Input.Mouse.OverrideCursor = null;
                IsBusy = false;
            }

        }

        #endregion // ICommand Members

        public static Stopwatch stopwatch;

        #region UpdateBusy
        static bool _isBusy = false;
        public static bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnBusyChange();
            }
        }

        public static event EventHandler BusyChange;
        public static void OnBusyChange()
        {
            EventHandler handler = BusyChange;
            if (handler != null)
                handler(null, EventArgs.Empty);
        }
        #endregion // UpdateBusy
    }
}
