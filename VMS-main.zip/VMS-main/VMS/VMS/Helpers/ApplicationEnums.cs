﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMS.Helpers
{
    internal enum MainViewType : byte
    {
        Main = 0 ,
        Module,
        Device,
        Card,
        Reports,

    }
}
