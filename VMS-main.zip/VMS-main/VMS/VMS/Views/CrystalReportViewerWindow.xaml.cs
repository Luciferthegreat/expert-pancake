﻿using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using VMS.DataAccess;
using VMS.DataAccess.Helpers;
using VMS.Reports;


namespace VMS.Views
{
    /// <summary>
    /// Interaction logic for CrystalReportViewerWindow.xaml
    /// </summary>
    public partial class CrystalReportViewerWindow : Window
    {
        #region Variables
        VMS.DataAccess.Helpers.Enums.ReportTypes _ReportTypes;
        #endregion

        #region Ctor
        public CrystalReportViewerWindow(VMS.DataAccess.Helpers.Enums.ReportTypes p_ReportTypes)
        {
            InitializeComponent();
            System.Windows.Input.Mouse.OverrideCursor = null;
            this.Loaded += CrystalReportViewerWindow_Loaded;
            _ReportTypes = p_ReportTypes;
        }
        #endregion

        #region Properties
        private DateTime? _FromDate;
        public DateTime? FromDate
        {
            get { return _FromDate; }
            set { _FromDate = value; }
        }

        private DateTime? _ToDate;
        public DateTime? ToDate
        {
            get { return _ToDate; }
            set { _ToDate = value; }
        }

        private string _CardId;
        public string CardId
        {
            get { return _CardId; }
            set { _CardId = value; }
        }

        private string _DeviceName;
        public string DeviceName
        {
            get { return _DeviceName; }
            set { _DeviceName = value; }
        }

        private string _ContactNo;
        public string ContactNo
        {
            get { return _ContactNo; }
            set { _ContactNo = value; }
        }

        private string _VisitorName;
        public string VisitorName
        {
            get { return _VisitorName; }
            set { _VisitorName = value; }
        }
        #endregion

        void CrystalReportViewerWindow_Loaded(object sender, RoutedEventArgs e)
        {
            //rptModuleDetails _rptModuleDetails = new rptModuleDetails();
            //CrystalReportsViewer.ViewerCore.ReportSource = _rptModuleDetails;
            //_rptModuleDetails.SetParameterValue("@FromDate", FromDate);
            //_rptModuleDetails.SetParameterValue("@ToDate", ToDate);
            //_rptModuleDetails.SetParameterValue("@CardID", CardId);
            //_rptModuleDetails.SetParameterValue("@DeviceName", DeviceName);
            //_rptModuleDetails.Refresh();


            rptCustomReport _rptCustomReport = new rptCustomReport();
            CustomDataSet CustomDataSet = GetReportData(_rptCustomReport);
            _rptCustomReport.SetDataSource(CustomDataSet);
            _rptCustomReport.Refresh();
            CrystalReportsViewer.ViewerCore.ReportSource = _rptCustomReport;
        }

        private CustomDataSet GetReportData(ReportDocument crystalReport)
        {
            EventsRepository _EventsRepository = new EventsRepository();
            List<VMS.DataModels.Models.LiveEvent> _LiveEventList = new List<VMS.DataModels.Models.LiveEvent>();

            if (_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.Date)
            {
                _LiveEventList = _EventsRepository.GetEvents(VMS.DataAccess.Helpers.Enums.ReportTypes.Date, FromDate, ToDate);
            }

            if (_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.Card)
            {
                _LiveEventList = _EventsRepository.GetEvents(VMS.DataAccess.Helpers.Enums.ReportTypes.Card, null, null, CardId);
            }

            if (_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.Device)
            {
                _LiveEventList = _EventsRepository.GetEvents(VMS.DataAccess.Helpers.Enums.ReportTypes.Device, null, null, "", DeviceName);
            }

            if (_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.VisitorContactNo)
            {
                _LiveEventList = _EventsRepository.GetEvents(VMS.DataAccess.Helpers.Enums.ReportTypes.VisitorContactNo, null, null, "", "", ContactNo);
            }

            if (_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.VisitorName)
            {
                _LiveEventList = _EventsRepository.GetEvents(VMS.DataAccess.Helpers.Enums.ReportTypes.VisitorName, null, null, "", "", "", VisitorName);
            }

            CustomDataSet _CustomDataSet = new CustomDataSet();

            //Get the List of all TextObjects in Section2 and set the header.
            //List<TextObject> textObjects = crystalReport.ReportDefinition.Sections["Section2"].ReportObjects.OfType<TextObject>().ToList();
            //for (int i = 0; i < textObjects.Count; i++)
            //{
            //    //Set the name of Column in TextObject.
            //    textObjects[i].Text = string.Empty;
            //    if (_LiveEventList.Count() > i)
            //    {
            //        //textObjects[i].Text = _LiveEventList.GetName(i);
            //        textObjects[i].Text = "header" + i;
            //    }
            //}


            foreach(VMS.DataModels.Models.LiveEvent _LiveEvent in _LiveEventList)
            {
                DataRow _DataRow = _CustomDataSet.Tables[0].Rows.Add();
                _DataRow[0] = _LiveEvent.ModuleName;
                _DataRow[1] = _LiveEvent.DeviceName;
                _DataRow[2] = _LiveEvent.CardID;
            }

            return _CustomDataSet;
        }
    }
}
