﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace VMS.Views
{
    /// <summary>
    /// Interaction logic for GeneralReportParameterWindow.xaml
    /// </summary>
    public partial class GeneralReportParameterWindow : MetroWindow
    {
        #region Variables
        VMS.DataAccess.Helpers.Enums.ReportTypes _ReportTypes;
        #endregion

        #region Ctor
        public GeneralReportParameterWindow(VMS.DataAccess.Helpers.Enums.ReportTypes p_ReportTypes)
        {
            InitializeComponent();
            System.Windows.Input.Mouse.OverrideCursor = null;
            this.Loaded += GeneralReportParameterWindow_Loaded;
            _ReportTypes = p_ReportTypes;
        }
        #endregion

        void GeneralReportParameterWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.Date)
            {
                gDateWise.Visibility = System.Windows.Visibility.Visible;
            }

            if (_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.Card)
            {
                gCardWise.Visibility = System.Windows.Visibility.Visible;
            }

            if (_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.Device)
            {
                gDeviceWise.Visibility = System.Windows.Visibility.Visible;
            }

            if (_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.VisitorContactNo)
            {
                gVisitorContactNoWise.Visibility = System.Windows.Visibility.Visible;
            }

            if (_ReportTypes == VMS.DataAccess.Helpers.Enums.ReportTypes.VisitorName)
            {
                gVisitorNameWise.Visibility = System.Windows.Visibility.Visible;
            }
        }

        private void btnOk_Click(object sender, RoutedEventArgs e)
        {
            CrystalReportViewerWindow _CrystalReportViewerWindow = new CrystalReportViewerWindow(VMS.DataAccess.Helpers.Enums.ReportTypes.Card);
            _CrystalReportViewerWindow.FromDate = dpFromDate.SelectedDate;
            _CrystalReportViewerWindow.ToDate = dpToDate.SelectedDate;
            _CrystalReportViewerWindow.CardId = tbCardID.Text.Trim();
            _CrystalReportViewerWindow.DeviceName = tbDeviceName.Text.Trim();
            _CrystalReportViewerWindow.ContactNo = tbContactNo.Text.Trim();
            _CrystalReportViewerWindow.VisitorName = tbVisitorName.Text.Trim();
            _CrystalReportViewerWindow.ShowDialog();
        }
    }
}
