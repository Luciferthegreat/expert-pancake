﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using VMS.DataModels.Models;
using VMS.ViewModels;
using WebEye.Controls.Wpf;
using VMS.Helpers;

namespace VMS.Views
{
    /// <summary>
    /// Interaction logic for CardDetailWindow.xaml
    /// </summary>
    public partial class CardDetailWindow : MetroWindow
    {
        #region Variables
        #endregion

        #region Ctor
        public CardDetailWindow()
        {
            InitializeComponent();
            InitializeWebCamSource();
            this.Loaded += CardDetailWindow_Loaded;
        }
        #endregion

        #region Methods
        public bool SaveValidation()
        {
            if (string.IsNullOrWhiteSpace(tbCardNumber.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter card number!", "Please enter card name", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbPurpose.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter purpose!", "Please enter purpose", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbWhomeToMeet.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter whome to meet!", "Please enter whome to meet", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbContactNo.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter contact no!", "Please enter contact no", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                return false;
            }

            return true;
        }

        private void InitializeWebCamSource()
        {
            cmbWebCamSource.ItemsSource = webCamControl.GetVideoCaptureDevices();

            if (cmbWebCamSource.Items.Count > 0)
            {
                cmbWebCamSource.SelectedItem = cmbWebCamSource.Items[0];
            }
        }

        private void StartWebCamCapture()
        {
            imgUserImage.Visibility = System.Windows.Visibility.Collapsed;
            btnCapturePhoto.Visibility = System.Windows.Visibility.Visible;
            grdWebCamCapture.Visibility = System.Windows.Visibility.Visible;
            btnStartStopWebCam.IsEnabled = (cmbWebCamSource.Items.Count > 0);
            btnStartStopWebCam.Visibility = System.Windows.Visibility.Visible;
            btnSaveWebCamImage.Visibility = System.Windows.Visibility.Visible;

        }

        private void StopCameraCapture()
        {
            grdWebCamCapture.Visibility = System.Windows.Visibility.Collapsed;
            var cameraId = (WebCameraId)cmbWebCamSource.SelectedItem;

            if (webCamControl.IsCapturing)
                webCamControl.StopCapture();

            btnStartStopWebCam.Visibility = System.Windows.Visibility.Collapsed;
            btnSaveWebCamImage.Visibility = System.Windows.Visibility.Collapsed;
            //btnChoosePhoto.Visibility = System.Windows.Visibility.Visible;
            imgUserImage.Visibility = System.Windows.Visibility.Visible;
            btnCapturePhoto.Visibility = System.Windows.Visibility.Visible;
        }
        #endregion

        #region Properties

        private CardMaster _SelectedCardMaster;
        public CardMaster SelectedCardMaster
        {
            get { return _SelectedCardMaster; }
            set
            {
                _SelectedCardMaster = value;
            }
        }

        private CardViewModel _CardViewModel;

        public CardViewModel CardViewModel
        {
            get { return _CardViewModel; }
            set { _CardViewModel = value; }
        }

        #endregion

        #region Events
        void CardDetailWindow_Loaded(object sender, RoutedEventArgs e)
        {
            System.Windows.Input.Mouse.OverrideCursor = null;
            this.Activate();
            this.Focus();
            tbCardID.Focus();



            CardViewModel = this.DataContext as CardViewModel;

            if (SelectedCardMaster != null)
            {
                tbCardID.Text = SelectedCardMaster.CardID;
                tbCardNumber.Text = SelectedCardMaster.CardNumber;
                tbUserName.Text = SelectedCardMaster.UserName;
                dpAccessStartDate.SelectedDate = SelectedCardMaster.AccessStartDate;
                dpAccessEndDate.SelectedDate = SelectedCardMaster.AccessEndDate;
                tbPurpose.Text = SelectedCardMaster.Purpose;
                tbWhomeToMeet.Text = SelectedCardMaster.WhomeToMeet;
                //Photo
                tbDepartment.Text = SelectedCardMaster.Department;
                tbExtraDetails.Text = SelectedCardMaster.ExtraDetails;
                tbAddress.Text = SelectedCardMaster.Address;
                tbContactNo.Text = SelectedCardMaster.ContactNo;
                tbIdProofType.Text = SelectedCardMaster.IdProofType;
                tbIdProofNumber.Text = SelectedCardMaster.IdProofNumber;
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (SaveValidation() != true)
            {
                return;
            }

            CardMaster _CardMaster = new CardMaster();

            if (SelectedCardMaster != null)
            {
                _CardMaster.CardPrimaryID = SelectedCardMaster.CardPrimaryID;
                _CardMaster.CardUpdateDate = DateTime.Now;
            }

            _CardMaster.CardID = tbCardID.Text;
            _CardMaster.UserName = tbUserName.Text;
            _CardMaster.CardNumber = tbCardNumber.Text;
            _CardMaster.AccessStartDate = dpAccessStartDate.SelectedDate;
            _CardMaster.AccessEndDate = dpAccessEndDate.SelectedDate;
            _CardMaster.Purpose = tbPurpose.Text;
            _CardMaster.WhomeToMeet = tbWhomeToMeet.Text;
            _CardMaster.Photo = CardViewModel.CardPhotoString;
            _CardMaster.Department = tbDepartment.Text;
            _CardMaster.ExtraDetails = tbExtraDetails.Text;
            _CardMaster.Address = tbAddress.Text;
            _CardMaster.ContactNo = tbContactNo.Text;
            _CardMaster.IdProofType = tbIdProofType.Text;
            _CardMaster.IdProofNumber = tbIdProofNumber.Text;

            if (CardViewModel._CardRepository.GetCardByIdAndNumber(_CardMaster).Count() > 0)
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Card with same Id or Number should not be allowed.", "Not be allowed", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                tbCardID.Focus();
                return;
            }

            CardViewModel._CardRepository.InsertOrUpdateCard(_CardMaster);

            CommonMessageWindow _CommonMessageWindowTwo = new CommonMessageWindow("Record saved successfully.", "Record saved", MessageBoxImage.Exclamation, MessageBoxButton.OK);
            _CommonMessageWindowTwo.ShowDialog();
            this.Close();
        }

        private void btnCapturePhoto_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StartWebCamCapture();
            }
            catch (Exception ex)
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Error Fetching stream from Camera.", "Fetching error", MessageBoxImage.Error, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
            }
        }

        private void btnCaputre_Click(object sender, RoutedEventArgs e)
        {
            if (false.Equals(webCamControl.IsCapturing))
            {
                var cameraId = (WebCameraId)cmbWebCamSource.SelectedItem;
                webCamControl.StartCapture(cameraId);
                btnStartStopWebCam.Content = "Stop";
                return;
            }
            webCamControl.StopCapture();
            btnStartStopWebCam.Content = "Start";
        }

        private void btnSaveWebCamImage_Click(object sender, RoutedEventArgs e)
        {
            if (webCamControl.IsCapturing)
            {
                //TODO:
                string imageStr = webCamControl.GetCurrentImage().ConvertBitmapToBase64String();
                CardViewModel.CardPhotoString = imageStr;


                StopCameraCapture();
                btnStartStopWebCam.Content = "Start";

            }
        }
        #endregion

        private void MetroWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            //this.Close();
            GC.Collect(1, GCCollectionMode.Forced);
        }
    }
}
