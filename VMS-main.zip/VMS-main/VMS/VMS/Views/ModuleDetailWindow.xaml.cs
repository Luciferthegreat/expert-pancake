﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using VMS.DataModels.Models;
using VMS.ViewModels;

namespace VMS.Views
{
    /// <summary>
    /// Interaction logic for ModuleDetailWindow.xaml
    /// </summary>
    public partial class ModuleDetailWindow : MetroWindow
    {
        #region Variables
        #endregion

        #region Ctor
        public ModuleDetailWindow()
        {
            InitializeComponent();
            this.Loaded += ModuleDetailWindow_Loaded;
        }
        #endregion

        #region Methods
        public bool SaveValidation()
        {
            if (string.IsNullOrWhiteSpace(tbName.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter module name!", "Please enter module name", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                tbName.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbIP.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter module ip!", "Please enter module ip", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                tbIP.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbPort.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter module port!", "Please enter module port", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                tbPort.Focus();
                return false;
            }

            //This validation is not needed as of nw
            //if (string.IsNullOrWhiteSpace(tbPassword.Password))
            //{
            //    CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter module password!", "Please enter module password", MessageBoxImage.Exclamation, MessageBoxButton.OK);
            //    _CommonMessageWindow.ShowDialog();
            //    tbPassword.Focus();
            //    return false;
            //}

            return true;
        }
        #endregion

        #region Properties

        private ModuleMaster _SelectedModuleMaster;
        public ModuleMaster SelectedModuleMaster
        {
            get { return _SelectedModuleMaster; }
            set
            {
                _SelectedModuleMaster = value;
            }
        }

        private ModuleViewModel _ModuleViewModel;

        public ModuleViewModel ModuleViewModel
        {
            get { return _ModuleViewModel; }
            set { _ModuleViewModel = value; }
        }

        #endregion

        #region Events
        void ModuleDetailWindow_Loaded(object sender, RoutedEventArgs e)
        {
            System.Windows.Input.Mouse.OverrideCursor = null;
            this.Activate();
            this.Focus();
            tbName.Focus();

            ModuleViewModel = this.DataContext as ModuleViewModel;

            if (SelectedModuleMaster != null)
            {
                tbName.Text = SelectedModuleMaster.ModuleName;
                tbIP.Text = SelectedModuleMaster.ModuleIP;
                tbPort.Text = SelectedModuleMaster.ModulePort;
                tbPassword.Password = SelectedModuleMaster.Password;
                tbTimeOut.Text = Convert.ToString(SelectedModuleMaster.TimeOut);
                cbIsEnabled.IsChecked = SelectedModuleMaster.IsEnabled;
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (SaveValidation() != true)
            {
                return;
            }

            ModuleMaster _ModuleMaster = new ModuleMaster();

            if(SelectedModuleMaster != null)
            {
                _ModuleMaster.ModuleId = SelectedModuleMaster.ModuleId;
                _ModuleMaster.ModuleUpdateDate = DateTime.Now;
            }

            _ModuleMaster.ModuleName = tbName.Text;
            _ModuleMaster.ModuleIP = tbIP.Text;
            _ModuleMaster.ModulePort = tbPort.Text;
            _ModuleMaster.Password = tbPassword.Password;
            _ModuleMaster.TimeOut = Convert.ToInt32(tbTimeOut.Text);
            _ModuleMaster.IsEnabled = cbIsEnabled.IsChecked;

            if (ModuleViewModel._ModuleRepository.GetModuleByNameAndIp(_ModuleMaster).Count() > 0)
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Module with same name or IP should not be allowed.", "Not be allowed", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                tbName.Focus();
                return;
            }

            ModuleViewModel._ModuleRepository.InsertOrUpdateModule(_ModuleMaster);

            CommonMessageWindow _CommonMessageWindowTwo = new CommonMessageWindow("Record saved successfully.", "Record saved", MessageBoxImage.Exclamation, MessageBoxButton.OK);
            _CommonMessageWindowTwo.ShowDialog();
            this.Close();
        }
        #endregion
    }
}
