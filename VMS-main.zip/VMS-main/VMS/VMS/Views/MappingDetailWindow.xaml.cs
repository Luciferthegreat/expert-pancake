﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using VMS.DataModels.CommonModels;
using VMS.DataModels.Models;
using VMS.ViewModels;

namespace VMS.Views
{
    /// <summary>
    /// Interaction logic for MappingDetailWindow.xaml
    /// </summary>
    public partial class MappingDetailWindow : MetroWindow
    {
        #region Variables
        #endregion

        #region Ctor
        public MappingDetailWindow()
        {
            InitializeComponent();
            this.Loaded += CardDeviceMappingWindow_Loaded;
        }
        #endregion

        #region Methods
        public bool SaveValidation()
        {
            if (string.IsNullOrWhiteSpace(cbModule.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter module name!", "Please enter module name", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                cbModule.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(cbDevice.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter device name!", "Please enter device name", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                cbDevice.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(cbCard.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter card name!", "Please enter card name", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                cbCard.Focus();
                return false;
            }

            return true;
        }
        #endregion

        #region Properties

        private MappingClass _SelectedMappingClass;
        public MappingClass SelectedMappingClass
        {
            get { return _SelectedMappingClass; }
            set
            {
                _SelectedMappingClass = value;
            }
        }

        private MappingViewModel _MappingViewModel;

        public MappingViewModel MappingViewModel
        {
            get { return _MappingViewModel; }
            set { _MappingViewModel = value; }
        }

        #endregion

        #region Events
        void CardDeviceMappingWindow_Loaded(object sender, RoutedEventArgs e)
        {
            System.Windows.Input.Mouse.OverrideCursor = null;
            this.Activate();
            this.Focus();
            cbModule.Focus();

            MappingViewModel = this.DataContext as MappingViewModel;

            if (SelectedMappingClass != null)
            {
                cbModule.Text = SelectedMappingClass.ModuleName;
                cbDevice.Text = SelectedMappingClass.DeviceName;
                cbCard.Text = SelectedMappingClass.CardID;
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (SaveValidation() != true)
            {
                return;
            }

            MappingClass _MappingClass = new MappingClass();

            if (SelectedMappingClass != null)
            {
                _MappingClass.CardDeviceMappingID = SelectedMappingClass.CardDeviceMappingID;
                _MappingClass.DeviceUpdateDate = DateTime.Now;
            }

            _MappingClass.ModuleId = (cbModule.SelectedItem as ModuleMaster).ModuleId;
            _MappingClass.DeviceID = (cbDevice.SelectedItem as DeviceMaster).DeviceID;
            _MappingClass.CardPrimaryID = (cbCard.SelectedItem as CardMaster).CardPrimaryID;

            MappingViewModel._MappingRepository.InsertOrUpdateMapping(_MappingClass);

            CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Record saved successfully.", "Record saved", MessageBoxImage.Exclamation, MessageBoxButton.OK);
            _CommonMessageWindow.ShowDialog();
            this.Close();
        }
        #endregion
    }
}
