﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace VMS.Views
{
    /// <summary>
    /// Interaction logic for CommonMessageWindow.xaml
    /// </summary>
    public partial class CommonMessageWindow : MetroWindow
    {
        #region Variables
        public static string _message = string.Empty;
        public static string _title = string.Empty;
        public static MessageBoxImage _img;
        public MessageBoxResult _result;
        public static MessageBoxButton _button;
        public string _imgPath;
        #endregion

        #region ctor
        public CommonMessageWindow()
        {
            InitializeComponent();
            System.Windows.Input.Mouse.OverrideCursor = null;
        }

        public CommonMessageWindow(string p_message, string p_title, MessageBoxImage p_img, MessageBoxButton p_button)
        {
            InitializeComponent();
            System.Windows.Input.Mouse.OverrideCursor = null;
            lblMessage.Text = p_message;
            this.Title = p_title;
            _button = p_button;
            _img = p_img;
        }
        #endregion

        #region Events
        private void MetroWindow_Loaded(object sender, RoutedEventArgs e)
        {
            lblMessage.VerticalAlignment = VerticalAlignment.Center;
            ShowData();
        }

        private void btnok_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            _result = MessageBoxResult.OK;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            _result = MessageBoxResult.Cancel;
        }

        private void btnYes_Click(object sender, RoutedEventArgs e)
        {
            _result = MessageBoxResult.Yes;
            this.Close();
        }

        private void btnNo_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            _result = MessageBoxResult.No;
        }
        #endregion

        #region Method
        public void ShowData()
        {
            if (_button == MessageBoxButton.YesNo)
            {
                stkYesNo.Visibility = Visibility.Visible;
            }
            else if (_button == MessageBoxButton.OKCancel)
            {
                stkOkCancel.Visibility = Visibility.Visible;
            }
            else if (_button == MessageBoxButton.OK)
            {
                stkOkCancel.Visibility = Visibility.Visible;
                btnCancel.Visibility = Visibility.Collapsed;
            }
            else if (_button == MessageBoxButton.YesNoCancel)
            {
                stkYesNoCancel.Visibility = Visibility.Visible;
            }

            if (_img == MessageBoxImage.Exclamation)
            {
                ImgExcplation.Visibility = Visibility.Visible;
            }
            else if (_img == MessageBoxImage.Warning)
            {
                ImgWarning.Visibility = Visibility.Visible;
            }
            else if (_img == MessageBoxImage.Information)
            {
                ImgInformation.Visibility = Visibility.Visible;
            }
            else if (_img == MessageBoxImage.Question)
            {
                ImgQuestion.Visibility = Visibility.Visible;
            }
            else if (_img == MessageBoxImage.Stop)
            {
                ImgStop.Visibility = Visibility.Visible;
            }
            else if (_img == MessageBoxImage.Error)
            {
                ImgError.Visibility = Visibility.Visible;
            }
        }
        #endregion
    }
}
