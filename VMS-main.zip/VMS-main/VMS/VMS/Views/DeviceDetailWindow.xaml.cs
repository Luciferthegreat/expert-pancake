﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using VMS.DataModels.Models;
using VMS.ViewModels;

namespace VMS.Views
{
    /// <summary>
    /// Interaction logic for DeviceDetailWindow.xaml
    /// </summary>
    public partial class DeviceDetailWindow : MetroWindow
    {
        #region Variables
        #endregion

        #region Ctor
        public DeviceDetailWindow()
        {
            InitializeComponent();
            this.Loaded += DeviceDetailWindow_Loaded;
        }
        #endregion

        #region Methods
        public bool SaveValidation()
        {
            if (string.IsNullOrWhiteSpace(cbModuleName.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter module name!", "Please enter module name", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                cbModuleName.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbDeviceName.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter device name!", "Please enter device name", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                tbDeviceName.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(tbAddress.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter address!", "Please enter address", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                tbAddress.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(cbDeviceNo.Text))
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Please enter device no!", "Please enter device no", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                cbDeviceNo.Focus();
                return false;
            }

            return true;
        }
        #endregion

        #region Properties

        private DeviceMaster _SelectedDeviceMaster;
        public DeviceMaster SelectedDeviceMaster
        {
            get { return _SelectedDeviceMaster; }
            set
            {
                _SelectedDeviceMaster = value;
            }
        }

        private DeviceViewModel _DeviceViewModel;

        public DeviceViewModel DeviceViewModel
        {
            get { return _DeviceViewModel; }
            set { _DeviceViewModel = value; }
        }

        #endregion

        #region Events
        void DeviceDetailWindow_Loaded(object sender, RoutedEventArgs e)
        {
            System.Windows.Input.Mouse.OverrideCursor = null;
            this.Activate();
            this.Focus();
            cbModuleName.Focus();

            DeviceViewModel = this.DataContext as DeviceViewModel;

            if (SelectedDeviceMaster != null)
            {
                cbModuleName.Text = SelectedDeviceMaster.ModuleName;
                tbDeviceName.Text = SelectedDeviceMaster.DeviceName;
                tbAddress.Text = SelectedDeviceMaster.DeviceAddress;
                cbIsEnabled.IsChecked = SelectedDeviceMaster.IsEnabled;
                cbDeviceNo.Text = Convert.ToString(SelectedDeviceMaster.DeviceNo);
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (SaveValidation() != true)
            {
                return;
            }

            DeviceMaster _DeviceMaster = new DeviceMaster();

            if(SelectedDeviceMaster != null)
            {
                _DeviceMaster.DeviceID = SelectedDeviceMaster.DeviceID;
                _DeviceMaster.DeviceUpdateDate = DateTime.Now;
            }

            _DeviceMaster.ModuleId = (cbModuleName.SelectedItem as ModuleMaster).ModuleId;
            _DeviceMaster.DeviceName = tbDeviceName.Text;
            _DeviceMaster.DeviceAddress = tbAddress.Text;
            _DeviceMaster.IsEnabled = cbIsEnabled.IsChecked;
            _DeviceMaster.DeviceNo = Convert.ToInt16(cbModuleName.Text);

            if (DeviceViewModel._DeviceRepository.GetDeviceByName(_DeviceMaster).Count() > 0)
            {
                CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Device with same name should not be allowed.", "Not be allowed", MessageBoxImage.Exclamation, MessageBoxButton.OK);
                _CommonMessageWindow.ShowDialog();
                tbDeviceName.Focus();
                return;
            }

            DeviceViewModel._DeviceRepository.InsertOrUpdateDevice(_DeviceMaster);

            CommonMessageWindow _CommonMessageWindowTwo = new CommonMessageWindow("Record saved successfully.", "Record saved", MessageBoxImage.Exclamation, MessageBoxButton.OK);
            _CommonMessageWindowTwo.ShowDialog();
            this.Close();
        }
        #endregion
    }
}
