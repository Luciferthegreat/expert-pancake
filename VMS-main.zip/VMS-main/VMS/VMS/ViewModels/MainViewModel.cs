﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using VMS.Helpers;
using VMS.Views;
using System.Threading;
using VMS.DataModels.Models;
using System.Collections.ObjectModel;
using VMS.DataModels;
using VMS.DataAccess;
using VMS.DeviceAccess;

namespace VMS.ViewModels
{
    public class MainViewModel : BaseModel
    {
        #region Variables
        #endregion

        #region Ctor
        public MainViewModel()
        {
            //CollectionOfLiveCardEvents = new ObservableCollection<LiveEvent>();
        }
        #endregion

        #region Properties

        public bool IsDBConnected
        {
            get
            {
                return !string.IsNullOrEmpty(App.AppConnectionString);
            }

        }


        private ImageSource _UserPicture = new BitmapImage(new Uri(@"/VMS;component/Images/User.png", UriKind.Relative));
        public ImageSource UserPicture
        {
            get
            {
                return _UserPicture;
            }
            set
            {
                _UserPicture = value;
                //OnPropertyChanged("UserPicture");
            }
        }

        private ModuleViewModel _ModuleViewModel = new ModuleViewModel();
        public ModuleViewModel ModuleViewModel
        {
            get { return _ModuleViewModel; }
            set { _ModuleViewModel = value; }
        }

        //private ObservableCollection<LiveEvent> _CollectionOfLiveCardEvents;
        //public ObservableCollection<LiveEvent> CollectionOfLiveCardEvents
        //{
        //    get { return _CollectionOfLiveCardEvents; }
        //    set { _CollectionOfLiveCardEvents = value; OnPropertyChanged("CollectionOfLiveCardEvents"); }
        //}

        //private LiveEvent _SelectedLiveCardEvents;

        //public LiveEvent SelectedLiveCardEvents
        //{
        //    get { return _SelectedLiveCardEvents; }
        //    set { _SelectedLiveCardEvents = value; OnPropertyChanged("SelectedLiveCardEvents"); }
        //}


        #endregion

        #region Mehods

        

        #endregion

       

        #region Commands

        #region Open Module Details List Command
        private RelayCommand _OpenModuleDetailsListCommand;
        public ICommand OpenModuleDetailsListCommand
        {
            get
            {
                if (_OpenModuleDetailsListCommand == null)
                    _OpenModuleDetailsListCommand = new RelayCommand(OnOpenModuleDetailsListCommand);
                return _OpenModuleDetailsListCommand;
            }
        }

        private void OnOpenModuleDetailsListCommand(object p_Name)
        {
            ModuleViewModel _ModuleViewModel = new ModuleViewModel();
            ModuleDetailListWindow _ModuleDetailListWindow = new ModuleDetailListWindow();
            _ModuleDetailListWindow.DataContext = _ModuleViewModel;
            _ModuleDetailListWindow.ShowDialog();
        }
        #endregion

        #region Open Device Details List Command
        private RelayCommand _OpenDeviceDetailsListCommand;
        public ICommand OpenDeviceDetailsListCommand
        {
            get
            {
                if (_OpenDeviceDetailsListCommand == null)
                    _OpenDeviceDetailsListCommand = new RelayCommand(OnOpenDeviceDetailsListCommand);
                return _OpenDeviceDetailsListCommand;
            }
        }

        private void OnOpenDeviceDetailsListCommand(object p_Name)
        {
            DeviceViewModel _DeviceViewModel = new DeviceViewModel();
            DeviceDetailListWindow _DeviceDetailListWindow = new DeviceDetailListWindow();
            _DeviceDetailListWindow.DataContext = _DeviceViewModel;
            _DeviceDetailListWindow.ShowDialog();
        }
        #endregion

        #region Open Card Details List Command
        private RelayCommand _OpenCardDetailsListCommand;
        public ICommand OpenCardDetailsListCommand
        {
            get
            {
                if (_OpenCardDetailsListCommand == null)
                    _OpenCardDetailsListCommand = new RelayCommand(OnOpenCardDetailsListCommand);
                return _OpenCardDetailsListCommand;
            }
        }

        private void OnOpenCardDetailsListCommand(object p_Name)
        {
            CardViewModel _CardViewModel = new CardViewModel();
            CardDetailListWindow _CardDetailListWindow = new CardDetailListWindow();
            _CardDetailListWindow.DataContext = _CardViewModel;
            _CardDetailListWindow.ShowDialog();
        }
        #endregion

        #region Open Mapping List Command
        private RelayCommand _OpenMappingListCommand;
        public ICommand OpenMappingListCommand
        {
            get
            {
                if (_OpenMappingListCommand == null)
                    _OpenMappingListCommand = new RelayCommand(OnMappingListCommand);
                return _OpenMappingListCommand;
            }
        }

        private void OnMappingListCommand(object p_Name)
        {
            MappingViewModel _MappingViewModel = new MappingViewModel();
            MappingListWindow _MappingListWindow = new MappingListWindow();
            _MappingListWindow.DataContext = _MappingViewModel;
            _MappingListWindow.ShowDialog();
        }
        #endregion

        #region Open General Report Parameter Command
        private RelayCommand _OpenGeneralReportParameterCommand;
        public ICommand OpenGeneralReportParameterCommand
        {
            get
            {
                if (_OpenGeneralReportParameterCommand == null)
                    _OpenGeneralReportParameterCommand = new RelayCommand(OnGeneralReportParameterCommand);
                return _OpenGeneralReportParameterCommand;
            }
        }

        private void OnGeneralReportParameterCommand(object p_Name)
        {
            VMS.DataAccess.Helpers.Enums.ReportTypes _ReportTypes = (VMS.DataAccess.Helpers.Enums.ReportTypes)System.Enum.Parse(typeof(VMS.DataAccess.Helpers.Enums.ReportTypes), p_Name.ToString());
            GeneralReportParameterWindow _GeneralReportParameterWindow = new GeneralReportParameterWindow(_ReportTypes);
            _GeneralReportParameterWindow.ShowDialog();
        }
        #endregion

        #endregion
    }
}
