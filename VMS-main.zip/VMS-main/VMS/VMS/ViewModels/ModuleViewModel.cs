﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Input;
using VMS.DataAccess;
using VMS.DataModels;
using VMS.DataModels.Models;
using VMS.Helpers;
using VMS.Views;
using VMS.Util;
using System.Windows;
using VMS.DeviceAccess;
using System.Threading;

namespace VMS.ViewModels
{
    public class ModuleViewModel : BaseModel
    {
        #region Variables
        public ModuleRepository _ModuleRepository = new ModuleRepository();
        EventsRepository eventRepo = new EventsRepository();
        System.Timers.Timer timr;
        #endregion

        #region Ctor
        public ModuleViewModel()
        {
            CollectionOfLiveCardEvents = new ObservableCollection<LiveEvent>();
            if (IsDBConnected)
            {
                FetchAllModules();
                ThreadPool.QueueUserWorkItem(delegate(object state)
                    {
                        TryConnectAllModules();
                    }, null);
                StartEventTimers();
            }
        }


        #endregion

        #region Properties

        public bool IsDBConnected
        {
            get
            {
                return !string.IsNullOrEmpty(App.AppConnectionString);
            }

        }

        private ObservableCollection<ModuleMaster> _CollectionOfModuleMaster;
        public ObservableCollection<ModuleMaster> CollectionOfModuleMaster
        {
            get { return _CollectionOfModuleMaster; }
            set { _CollectionOfModuleMaster = value; OnPropertyChanged("CollectionOfModuleMaster"); }
        }

        private ModuleMaster _SelectedModuleMaster;
        public ModuleMaster SelectedModuleMaster
        {
            get { return _SelectedModuleMaster; }
            set
            {
                _SelectedModuleMaster = value;
                OnPropertyChanged("SelectedModuleMaster");
            }
        }


        private ObservableCollection<LiveEvent> _CollectionOfLiveCardEvents;
        public ObservableCollection<LiveEvent> CollectionOfLiveCardEvents
        {
            get { return _CollectionOfLiveCardEvents; }
            set { _CollectionOfLiveCardEvents = value; OnPropertyChanged("CollectionOfLiveCardEvents"); }
        }

        private LiveEvent _SelectedLiveCardEvents;
        public LiveEvent SelectedLiveCardEvents
        {
            get { return _SelectedLiveCardEvents; }
            set { _SelectedLiveCardEvents = value; OnPropertyChanged("SelectedLiveCardEvents"); }
        }

        #endregion

        #region Mehods
        /// <summary>
        /// Gets All Modules from DB and attach its Event handlers
        /// </summary>
        private void FetchAllModules()
        {
            CollectionOfModuleMaster = _ModuleRepository.GetAllModule().ToObservableCollection();

            if (CollectionOfModuleMaster.Count > 0)
            {
                foreach (var module in CollectionOfModuleMaster)
                {
                    module.OnEventReceived -= module_OnEventReceived;
                    module.OnEventReceived += module_OnEventReceived;
                }
            }
        }

        private void TryConnectAllModules()
        {
            try
            {
                foreach (ModuleMaster module in CollectionOfModuleMaster)
                {
                    ConnectDisConnectModule(module);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void ConnectDisConnectModule(ModuleMaster p_ModuleToOperator)
        {
            if (!p_ModuleToOperator.DeviceAdapter.IsDeviceConnected)
            {
                p_ModuleToOperator.DeviceAdapter.ConnectDevice(this.SelectedModuleMaster.ModuleIP, this.SelectedModuleMaster.ModulePort, this.SelectedModuleMaster.Password);
                p_ModuleToOperator.OnPropertyChanged("IsDeviceConnected");
            }
            else
            {
                p_ModuleToOperator.DeviceAdapter.DisconnectDevice();
                p_ModuleToOperator.OnPropertyChanged("IsDeviceConnected");

            }
        }

        void module_OnEventReceived(DeviceEvent devEvent)
        {
            try
            {
                LiveEvent newEvent = new LiveEvent();
                ModuleMaster dbModule = GetModuleByDeviceID(devEvent.ModuleDBID);
                DeviceMaster device = GetDeviceByDeviceID(devEvent.ReaderDBID);
                CardMaster cardFound = GetCardByCardID(1);
                int eventType = new Random().Next((int)EventType.NormalPunchOpen, (int)EventType.DoorClosedCorrectly);
                if (cardFound != null && device != null && dbModule != null)
                {
                    newEvent.CardPrimaryID = 1;
                    newEvent.AccessEndDate = cardFound.AccessEndDate;
                    newEvent.AccessStartDate = cardFound.AccessStartDate;
                    newEvent.CardAddress = cardFound.Address;
                    newEvent.CardID = cardFound.CardID;
                    newEvent.CardNumber = cardFound.CardNumber;
                    newEvent.ContactNo = cardFound.ContactNo;
                    newEvent.Department = cardFound.Department;
                    newEvent.DeviceAddress = device.DeviceAddress;
                    newEvent.DeviceId = device.DeviceID;
                    newEvent.DeviceName = device.DeviceName;
                    newEvent.ExtraDetails = cardFound.ExtraDetails;
                    newEvent.IdProofNumber = cardFound.IdProofNumber;
                    newEvent.IdProofType = cardFound.IdProofType;
                    newEvent.ModuleId = device.ModuleId;
                    newEvent.ModuleIP = dbModule.ModuleIP;
                    newEvent.ModuleName = dbModule.ModuleName;
                    newEvent.ModulePassword = dbModule.Password;
                    newEvent.ModulePort = dbModule.ModulePort;
                    newEvent.ModuleTimeOut = dbModule.TimeOut;
                    newEvent.Photo = cardFound.Photo;
                    newEvent.Purpose = cardFound.Purpose;
                    newEvent.UserName = cardFound.UserName;
                    newEvent.WhomeToMeet = cardFound.WhomeToMeet;
                    newEvent.EventType = eventType;
                    newEvent.EventDateTime = DateTime.Now;
                    GenerateEvents(newEvent);
                }

            }
            catch (Exception ex)
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="timerInterval">Interval is in Miliseconds</param>
        public void StartEventTimers(int timerInterval = 2000)
        {
            if (!IsDBConnected)
            {
                System.Diagnostics.Debug.Write("DB Not Connected");
                return;
            }

            StopEventTimer();

            timr = new System.Timers.Timer(timerInterval);
            timr.Elapsed += timr_Elapsed;
            timr.Start();
        }

        void timr_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            timr.Enabled = false;

            if (!IsDBConnected)
            {
                System.Diagnostics.Debug.Write("DB Not Connected");
                return;
            }

            //TODO: Code for fetching all device events goes here
            foreach (var module in CollectionOfModuleMaster)
            {
                if (module.DeviceAdapter.IsDeviceConnected)
                {
                    module.DeviceAdapter.TryGetEvent();
                }
            }

            timr.Enabled = true;
        }

        private CardMaster GetCardByCardID(long cardID)
        {
            CardRepository cardRepo = new CardRepository();
            CardMaster cardFound = cardRepo.GetCardByCardPrimaryID(cardID).FirstOrDefault();
            return cardFound;
        }

        private DeviceMaster GetDeviceByDeviceID(long deviceID)
        {
            DeviceRepository cardRepo = new DeviceRepository();
            DeviceMaster deviceFound = cardRepo.GetDeviceByDeviceID(deviceID).FirstOrDefault();
            return deviceFound;
        }

        private ModuleMaster GetModuleByDeviceID(long moduleID)
        {
            ModuleRepository moduleRepo = new ModuleRepository();
            ModuleMaster moduleFound = moduleRepo.GetModuleByModuleId(moduleID).FirstOrDefault();
            return moduleFound;
        }


        public void StopEventTimer()
        {
            if (timr != null)
                timr.Stop();
        }


        private void GenerateEvents(LiveEvent newEventToBeAdded)
        {
            App.Current.Dispatcher.BeginInvoke(new Action(() =>
            {
                CollectionOfLiveCardEvents.Add(newEventToBeAdded);

                eventRepo.InsertLiveEvent(newEventToBeAdded);

                OnPropertyChanged("CollectionOfLiveCardEvents");
            }));
        }
        #endregion

        #region Commands

        #region Open Module Details Command
        private RelayCommand _OpenModuleDetailsCommand;
        public ICommand OpenModuleDetailsCommand
        {
            get
            {
                if (_OpenModuleDetailsCommand == null)
                    _OpenModuleDetailsCommand = new RelayCommand(OnOpenModuleDetailsCommand);
                return _OpenModuleDetailsCommand;
            }
        }

        private void OnOpenModuleDetailsCommand(object p_Name)
        {
            ModuleDetailWindow _ModuleDetailWindow = new ModuleDetailWindow();

            if (SelectedModuleMaster != null)
            {
                _ModuleDetailWindow.SelectedModuleMaster = SelectedModuleMaster;
            }

            _ModuleDetailWindow.DataContext = this;
            _ModuleDetailWindow.ShowDialog();
            FillModuleMaster.Execute(null);
        }
        #endregion

        #region Fill Module Command
        private RelayCommand _FillModuleMaster;
        public ICommand FillModuleMaster
        {
            get
            {
                if (_FillModuleMaster == null)
                    _FillModuleMaster = new RelayCommand(OnFillModuleMaster);
                return _FillModuleMaster;
            }
        }

        private void OnFillModuleMaster(object p_Name)
        {
            FetchAllModules();
        }
        #endregion

        #region Delete Module Command
        private RelayCommand _DeleteModuleMasterCommand;
        public ICommand DeleteModuleMasterCommand
        {
            get
            {
                if (_DeleteModuleMasterCommand == null)
                    _DeleteModuleMasterCommand = new RelayCommand(OnDeleteModuleMasterCommand);
                return _DeleteModuleMasterCommand;
            }
        }

        private void OnDeleteModuleMasterCommand(object p_Name)
        {
            CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Are you sure you want to delete?", "Delete selected record", MessageBoxImage.Question, MessageBoxButton.YesNo);
            _CommonMessageWindow.ShowDialog();
            if (_CommonMessageWindow._result == MessageBoxResult.Yes)
            {
                _ModuleRepository.DeleteModule(p_Name as ModuleMaster);
                FillModuleMaster.Execute(null);
            }
        }
        #endregion

        #region Connect Disconnect device
        private RelayCommand _ConnectModuleDetailsCommand;
        public ICommand ConnectDisConnectModuleDetailsCommand
        {
            get
            {
                if (_ConnectModuleDetailsCommand == null)
                    _ConnectModuleDetailsCommand = new RelayCommand(OnConnectDisConnectModuleDetailsCommand);
                return _ConnectModuleDetailsCommand;
            }
        }

        private void OnConnectDisConnectModuleDetailsCommand(object p_Name)
        {
            try
            {
                if (this.SelectedModuleMaster != null)
                {
                    ConnectDisConnectModule(this.SelectedModuleMaster);
                }
            }
            catch (Exception ex)
            {

            }
        }


        #endregion
        #endregion
    }
}
