﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Input;
using VMS.DataAccess;
using VMS.DataModels;
using VMS.DataModels.Models;
using VMS.Helpers;
using VMS.Views;
using VMS.Util;
using Microsoft.Win32;
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Windows.Media;

namespace VMS.ViewModels
{
    public class CardViewModel : BaseModel
    {
        #region Variables
        public CardRepository _CardRepository = new CardRepository();
        #endregion

        #region Ctor
        public CardViewModel()
        {
            CollectionOfCardMaster = _CardRepository.GetAllCard().ToObservableCollection();
        }
        #endregion

        #region Mehods
        #endregion

        #region Properties

        private ObservableCollection<CardMaster> _CollectionOfCardMaster;
        public ObservableCollection<CardMaster> CollectionOfCardMaster
        {
            get { return _CollectionOfCardMaster; }
            set { _CollectionOfCardMaster = value; OnPropertyChanged("CollectionOfCardMaster"); }
        }

        private CardMaster _SelectedCardMaster;
        public CardMaster SelectedCardMaster
        {
            get { return _SelectedCardMaster; }
            set
            {
                _SelectedCardMaster = value;
                OnPropertyChanged("SelectedCardMaster");
            }
        }

        public string cardPhotoString;
        public string CardPhotoString
        {
            get
            {
                if (SelectedCardMaster == null)
                    SelectedCardMaster = new CardMaster();
                return SelectedCardMaster.Photo;
            }
            set
            {
                if (SelectedCardMaster == null)
                    SelectedCardMaster = new CardMaster();
                SelectedCardMaster.Photo = value;
                OnPropertyChanged("CardPhotoString");
                OnPropertyChanged("CardPhoto");
            }
        }

        private BitmapImage _CardPhoto = new BitmapImage(new Uri(@"/VMS;component/Images/User.png", UriKind.Relative));
        public BitmapImage CardPhoto
        {
            get
            {
                if (SelectedCardMaster == null || string.IsNullOrEmpty(SelectedCardMaster.Photo))
                    return _CardPhoto;
                try
                {
                    BitmapImage bi = new BitmapImage();
                    bi.BeginInit();
                    bi.StreamSource = new MemoryStream(System.Convert.FromBase64String(SelectedCardMaster.Photo));
                    bi.EndInit();

                    return bi;
                }
                catch
                { return _CardPhoto; }
            }
        }

        #endregion

        #region Commands

        #region Open Card Details Command
        private RelayCommand _OpenCardDetailsCommand;
        public ICommand OpenCardDetailsCommand
        {
            get
            {
                if (_OpenCardDetailsCommand == null)
                    _OpenCardDetailsCommand = new RelayCommand(OnOpenCardDetailsCommand);
                return _OpenCardDetailsCommand;
            }
        }

        private void OnOpenCardDetailsCommand(object p_Name)
        {
            CardDetailWindow _CardDetailWindow = new CardDetailWindow();

            if (SelectedCardMaster != null)
            {
                _CardDetailWindow.SelectedCardMaster = SelectedCardMaster;
            }

            _CardDetailWindow.DataContext = this;
            _CardDetailWindow.ShowDialog();
            FillCardMaster.Execute(null);
        }
        #endregion

        #region Update Picture Command
        private RelayCommand _UpdatePictureCommand;
        public ICommand UpdatePictureCommand
        {
            get
            {
                if (_UpdatePictureCommand == null)
                    _UpdatePictureCommand = new RelayCommand(OnUpdatePictureCommand);
                return _UpdatePictureCommand;
            }
        }

        private void OnUpdatePictureCommand(object p_Name)
        {
            OpenFileDialog _OpenFileDialog = new OpenFileDialog();
            _OpenFileDialog.Filter = "Image File (*.jpg;*.bmp;*.gif)|*.jpg;*.bmp;*.gif";
            _OpenFileDialog.InitialDirectory = Environment.SpecialFolder.MyPictures.ToString();

            if (_OpenFileDialog.ShowDialog() == true)
            {
                #region This is for check file size
                var _FileLength = new FileInfo(_OpenFileDialog.FileName).Length;
                if (StaticValueHelper.ConvertBytesToMegabytes(_FileLength) > 1)
                {
                    CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Selected file is too large, Do you want to continue.", "File is too large", MessageBoxImage.Question, MessageBoxButton.YesNo);
                    _CommonMessageWindow.ShowDialog();
                    if (_CommonMessageWindow._result == MessageBoxResult.No)
                    {
                        return;
                    }
                }
                #endregion

                //CardPhoto = new BitmapImage(new Uri(_OpenFileDialog.FileName));

                if (SelectedCardMaster != null && SelectedCardMaster.Photo != null)
                {
                    SelectedCardMaster.Photo = null;
                }
            }
        }
        #endregion

        #region Fill Card Command
        private RelayCommand _FillCardMaster;
        public ICommand FillCardMaster
        {
            get
            {
                if (_FillCardMaster == null)
                    _FillCardMaster = new RelayCommand(OnFillCardMaster);
                return _FillCardMaster;
            }
        }

        private void OnFillCardMaster(object p_Name)
        {
            CollectionOfCardMaster = _CardRepository.GetAllCard().ToObservableCollection();
        }
        #endregion

        #region Delete Card Command
        private RelayCommand _DeleteCardMasterCommand;
        public ICommand DeleteCardMasterCommand
        {
            get
            {
                if (_DeleteCardMasterCommand == null)
                    _DeleteCardMasterCommand = new RelayCommand(OnDeleteCardMasterCommand);
                return _DeleteCardMasterCommand;
            }
        }

        private void OnDeleteCardMasterCommand(object p_Name)
        {
            CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Are you sure you want to delete?", "Delete selected record", MessageBoxImage.Question, MessageBoxButton.YesNo);
            _CommonMessageWindow.ShowDialog();
            if (_CommonMessageWindow._result == MessageBoxResult.Yes)
            {
                _CardRepository.DeleteCard(p_Name as CardMaster);
                FillCardMaster.Execute(null);
            }
        }
        #endregion

        #endregion
    }
}
