﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using VMS.DataAccess;
using VMS.DataModels;
using VMS.DataModels.CommonModels;
using VMS.DataModels.Models;
using VMS.Helpers;
using VMS.Util;
using VMS.Views;

namespace VMS.ViewModels
{
    public class MappingViewModel : BaseModel
    {
        #region Variables
        public MappingRepository _MappingRepository = new MappingRepository();
        ModuleRepository _ModuleRepository = new ModuleRepository();
        DeviceRepository _DeviceRepository = new DeviceRepository();
        CardRepository _CardRepository = new CardRepository();
        #endregion

        #region Ctor
        public MappingViewModel()
        {
            CollectionOfMappingClass = _MappingRepository.GetAllMapping().ToObservableCollection();
            CollectionOfModuleMaster = _ModuleRepository.GetAllModule().ToObservableCollection();
            CollectionOfDeviceMaster = _DeviceRepository.GetAllDevice().ToObservableCollection();
            CollectionOfCardMaster = _CardRepository.GetAllCard().ToObservableCollection();
        }
        #endregion

        #region Mehods

        #endregion

        #region Properties

        private ObservableCollection<MappingClass> _CollectionOfMappingClass;
        public ObservableCollection<MappingClass> CollectionOfMappingClass
        {
            get { return _CollectionOfMappingClass; }
            set { _CollectionOfMappingClass = value; OnPropertyChanged("CollectionOfMappingClass"); }
        }

        private MappingClass _SelectedMappingClass;
        public MappingClass SelectedMappingClass
        {
            get { return _SelectedMappingClass; }
            set
            {
                _SelectedMappingClass = value;
                OnPropertyChanged("SelectedMappingClass");
            }
        }

        private ObservableCollection<ModuleMaster> _CollectionOfModuleMaster;
        public ObservableCollection<ModuleMaster> CollectionOfModuleMaster
        {
            get { return _CollectionOfModuleMaster; }
            set { _CollectionOfModuleMaster = value; OnPropertyChanged("CollectionOfModuleMaster"); }
        }

        private ModuleMaster _SelectedModuleMaster;
        public ModuleMaster SelectedModuleMaster
        {
            get { return _SelectedModuleMaster; }
            set
            {
                _SelectedModuleMaster = value;
                OnPropertyChanged("SelectedModuleMaster");
            }
        }

        private ObservableCollection<DeviceMaster> _CollectionOfDeviceMaster;
        public ObservableCollection<DeviceMaster> CollectionOfDeviceMaster
        {
            get { return _CollectionOfDeviceMaster; }
            set { _CollectionOfDeviceMaster = value; OnPropertyChanged("CollectionOfDeviceMaster"); }
        }

        private DeviceMaster _SelectedDeviceMaster;
        public DeviceMaster SelectedDeviceMaster
        {
            get { return _SelectedDeviceMaster; }
            set
            {
                _SelectedDeviceMaster = value;
                OnPropertyChanged("SelectedDeviceMaster");
            }
        }

        private ObservableCollection<CardMaster> _CollectionOfCardMaster;
        public ObservableCollection<CardMaster> CollectionOfCardMaster
        {
            get { return _CollectionOfCardMaster; }
            set { _CollectionOfCardMaster = value; OnPropertyChanged("CollectionOfCardMaster"); }
        }

        private CardMaster _SelectedCardMaster;
        public CardMaster SelectedCardMaster
        {
            get { return _SelectedCardMaster; }
            set
            {
                _SelectedCardMaster = value;
                OnPropertyChanged("SelectedCardMaster");
            }
        }

        #endregion

        #region Commands

        #region Open Mapping Details Command
        private RelayCommand _OpenMappingDetailsCommand;
        public ICommand OpenMappingDetailsCommand
        {
            get
            {
                if (_OpenMappingDetailsCommand == null)
                    _OpenMappingDetailsCommand = new RelayCommand(OnOpenMappingDetailsCommand);
                return _OpenMappingDetailsCommand;
            }
        }

        private void OnOpenMappingDetailsCommand(object p_Name)
        {
            MappingDetailWindow _MappingDetailWindow = new MappingDetailWindow();

            if (SelectedMappingClass != null)
            {
                _MappingDetailWindow.SelectedMappingClass = SelectedMappingClass;
            }

            _MappingDetailWindow.DataContext = this;
            _MappingDetailWindow.ShowDialog();
            FillMappingCommand.Execute(null);
        }
        #endregion

        #region Fill Mapping Command
        private RelayCommand _FillMappingCommand;
        public ICommand FillMappingCommand
        {
            get
            {
                if (_FillMappingCommand == null)
                    _FillMappingCommand = new RelayCommand(OnMappingCommand);
                return _FillMappingCommand;
            }
        }

        private void OnMappingCommand(object p_Name)
        {
            CollectionOfMappingClass = _MappingRepository.GetAllMapping().ToObservableCollection();
        }
        #endregion

        #region Delete Mapping Command
        private RelayCommand _DeleteMappingCommand;
        public ICommand DeleteMappingCommand
        {
            get
            {
                if (_DeleteMappingCommand == null)
                    _DeleteMappingCommand = new RelayCommand(OnDeleteMappingCommand);
                return _DeleteMappingCommand;
            }
        }

        private void OnDeleteMappingCommand(object p_Name)
        {
            CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Are you sure you want to delete?", "Delete selected record", MessageBoxImage.Question, MessageBoxButton.YesNo);
            _CommonMessageWindow.ShowDialog();
            if (_CommonMessageWindow._result == MessageBoxResult.Yes)
            {
                _MappingRepository.DeleteMapping(p_Name as MappingClass);
                FillMappingCommand.Execute(null);
            }
        }
        #endregion

        #endregion
    }
}
