﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Input;
using VMS.DataAccess;
using VMS.DataModels;
using VMS.DataModels.Models;
using VMS.Helpers;
using VMS.Views;
using VMS.Util;
using System.Windows;

namespace VMS.ViewModels
{
    public class DeviceViewModel : BaseModel
    {
        #region Variables
        public DeviceRepository _DeviceRepository = new DeviceRepository();
        ModuleRepository _ModuleRepository = new ModuleRepository();
        #endregion

        #region Ctor
        public DeviceViewModel()
        {
            CollectionOfDeviceMaster = _DeviceRepository.GetAllDevice().ToObservableCollection();
            CollectionOfModuleMaster = _ModuleRepository.GetAllModule().ToObservableCollection();
        }
        #endregion

        #region Mehods

        #endregion

        #region Properties

        private ObservableCollection<DeviceMaster> _CollectionOfDeviceMaster;
        public ObservableCollection<DeviceMaster> CollectionOfDeviceMaster
        {
            get { return _CollectionOfDeviceMaster; }
            set { _CollectionOfDeviceMaster = value; OnPropertyChanged("CollectionOfDeviceMaster"); }
        }

        private DeviceMaster _SelectedDeviceMaster;
        public DeviceMaster SelectedDeviceMaster
        {
            get { return _SelectedDeviceMaster; }
            set
            {
                _SelectedDeviceMaster = value;
                OnPropertyChanged("SelectedDeviceMaster");
            }
        }

        private ObservableCollection<ModuleMaster> _CollectionOfModuleMaster;
        public ObservableCollection<ModuleMaster> CollectionOfModuleMaster
        {
            get { return _CollectionOfModuleMaster; }
            set { _CollectionOfModuleMaster = value; OnPropertyChanged("CollectionOfModuleMaster"); }
        }

        private ModuleMaster _SelectedModuleMaster;
        public ModuleMaster SelectedModuleMaster
        {
            get { return _SelectedModuleMaster; }
            set
            {
                _SelectedModuleMaster = value;
                OnPropertyChanged("SelectedModuleMaster");
            }
        }
        #endregion

        #region Commands

        #region Open Device Details Command
        private RelayCommand _OpenDeviceDetailsCommand;
        public ICommand OpenDeviceDetailsCommand
        {
            get
            {
                if (_OpenDeviceDetailsCommand == null)
                    _OpenDeviceDetailsCommand = new RelayCommand(OnOpenDeviceDetailsCommand);
                return _OpenDeviceDetailsCommand;
            }
        }

        private void OnOpenDeviceDetailsCommand(object p_Name)
        {
            DeviceDetailWindow _DeviceDetailWindow = new DeviceDetailWindow();

            if (SelectedDeviceMaster != null)
            {
                _DeviceDetailWindow.SelectedDeviceMaster = SelectedDeviceMaster;
            }

            _DeviceDetailWindow.DataContext = this;
            _DeviceDetailWindow.ShowDialog();
            FillDeviceMaster.Execute(null);
        }
        #endregion

        #region Fill Device Command
        private RelayCommand _FillDeviceMaster;
        public ICommand FillDeviceMaster
        {
            get
            {
                if (_FillDeviceMaster == null)
                    _FillDeviceMaster = new RelayCommand(OnFillDeviceMaster);
                return _FillDeviceMaster;
            }
        }

        private void OnFillDeviceMaster(object p_Name)
        {
            CollectionOfDeviceMaster = _DeviceRepository.GetAllDevice().ToObservableCollection();
        }
        #endregion

        #region Delete Device Command
        private RelayCommand _DeleteDeviceMasterCommand;
        public ICommand DeleteDeviceMasterCommand
        {
            get
            {
                if (_DeleteDeviceMasterCommand == null)
                    _DeleteDeviceMasterCommand = new RelayCommand(OnDeleteDeviceMasterCommand);
                return _DeleteDeviceMasterCommand;
            }
        }

        private void OnDeleteDeviceMasterCommand(object p_Name)
        {
            CommonMessageWindow _CommonMessageWindow = new CommonMessageWindow("Are you sure you want to delete?", "Delete selected record", MessageBoxImage.Question, MessageBoxButton.YesNo);
            _CommonMessageWindow.ShowDialog();
            if (_CommonMessageWindow._result == MessageBoxResult.Yes)
            {
                _DeviceRepository.DeleteDevice(p_Name as DeviceMaster);
                FillDeviceMaster.Execute(null);
            }
        }
        #endregion

        #endregion
    }
}
