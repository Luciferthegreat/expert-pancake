﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Data;
using VMS.Helpers;

namespace VMS.Convertors
{
    public class SelectedItemToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null || parameter == null)
                return "Collapsed";

            ListViewItem objItem = value as ListViewItem;
            if(objItem == null)
                return "Collapsed";


            MainViewType viewType = (MainViewType)Enum.Parse(typeof(MainViewType), parameter.ToString());
            MainViewType viewTypeValue = (MainViewType)Enum.Parse(typeof(MainViewType), objItem.Tag.ToString());
            if (viewTypeValue.Equals(viewType))
                return "Visible";

            return "Collapsed";
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
