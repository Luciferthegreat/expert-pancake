﻿using Microsoft.Data.ConnectionUI;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VMS.ViewModels;

namespace VMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    //[CLSCompliant(false)] // Because MetroWindow is not CLSCompliant
    public partial class MainWindow
    {
        #region Variables
        MainViewModel _MainViewModel;
        #endregion

        #region Ctor
        public MainWindow()
        {
            InitializeComponent();
            _MainViewModel = new MainViewModel();
            this.DataContext = _MainViewModel;
            this.Loaded += MainWindow_Loaded;
            this.Closing += MainWindow_Closing;
        }

        void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }
        #endregion

        #region Methods
        private void ShowDBConnectivityDialog()
        {
            try
            {
                using (var dialog = new DataConnectionDialog())
                {
                    DataSource.AddStandardDataSources(dialog);
                    dialog.DataSources.Add(DataSource.SqlDataSource);

                    System.Windows.Forms.DialogResult userChoice = DataConnectionDialog.Show(dialog);

                    if (userChoice == System.Windows.Forms.DialogResult.OK)
                    {
                        App.AppConnectionString = dialog.ConnectionString;
                        MessageBox.Show("Database Connection Saved Successfully.\r\nPlease restart the Application.", "Database Connection Successult");
                        App.Current.Shutdown();
                    }
                    else
                    {
                        if (string.Empty.Equals(App.AppConnectionString))
                            //MessageBox.Show("Application will exit.");
                            Application.Current.Shutdown();
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        #endregion

        #region Events
        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            //this.Activate();
            this.Topmost = false;
#if !DEBUG
            if (string.IsNullOrEmpty(App.AppConnectionString))
            {
                ShowDBConnectivityDialog();
                return;
            } 
#endif
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnConnectToDB_Click(object sender, RoutedEventArgs e)
        {
            ShowDBConnectivityDialog();
        }
        #endregion

    }
}
